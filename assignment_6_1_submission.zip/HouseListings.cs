﻿using Assignment_6_1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime;
using System.Text;

namespace Assignment_6_1
{
    enum Type
    {
        Unknown = 0,
        Ranch,
        Tudor,
        Craftsman,
        Cape_Cod,
        Colonial,
        Victorian,
        Modern_Farmhouse,
        Mediterranean,
        Contemporary
    }
    internal class House
    {
        public int HouseNumber { get; set; }
        public string HouseStreet { get; set; }
        public Type HouseType { get; set; }
        public House Next;
        
        public House(int num)
        {
            HouseNumber = num;
            Next = null;
        }
        public House(string street)
        {
            HouseStreet = street;
            Next = null;
        }
        public House(Type type)
        {
            HouseType = type;
            Next = null;
        }
        public House(int num, string street)
        {
            HouseNumber = num;
            HouseStreet = street;
            Next = null;
        }
        public House(int num, Type type)
        {
            HouseNumber = num;
            HouseType = type;
            Next = null;
        }
        public House(string street, Type type)
        {
            HouseStreet = street;
            HouseType = type;
            Next = null;
        }
        public House(int num, string street, Type type)
        {
            HouseNumber = num;
            HouseStreet = street;
            HouseType = type;
            Next = null;
        }
    }
    internal class HouseListings
    {
        private House head;
        private House tail;
        private int size;
        public int Size { get { return size; } }

        public HouseListings()
        {
            head = null;
            tail = null;
            size = 0;
        }

        public bool IsEmpty()
        {
            return size == 0;
        }
        public void AddToFront(int num)
        {
            House newHouse = new House(num);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(string street)
        {
            House newHouse = new House(street + " street");
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(Type type)
        {
            House newHouse = new House(type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(int num, string street)
        {
            House newHouse = new House(num, street + " street");
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(int num, Type type)
        {
            House newHouse = new House(num, type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(string street, Type type)
        {
            House newHouse = new House(street + " street", type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToFront(int num, string street, Type type)
        {
            House newHouse = new House(num, street + " street", type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                newHouse.Next = head;
                head = newHouse;
            }
            size++;
        }
        public void AddToBack(int num)
        {
            House newHouse = new House(num);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(string street)
        {
            House newHouse = new House(street + " street");
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(Type type)
        {
            House newHouse = new House(type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(int num, string street)
        {
            House newHouse = new House(num, street + " street");
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(int num, Type type)
        {
            House newHouse = new House(num, type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(string street, Type type)
        {
            House newHouse = new House(street + " street", type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddToBack(int num, string street, Type type)
        {
            House newHouse = new House(num, street + " street", type);
            if (IsEmpty())
            {
                this.head = newHouse;
                this.tail = newHouse;
            }
            else
            {
                tail.Next = newHouse;
                tail = newHouse;
            }
            size++;
        }
        public void AddAnywhere(int num, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(num);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(num);
                return;
            }
            House newHouse = new House(num);
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(string street, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(street);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(street);
                return;
            }
            House newHouse = new House(street + " street");
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(Type type, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(type);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(type);
                return;
            }
            House newHouse = new House(type);
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(int num, string street, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(num, street);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(num, street);
                return;
            }
            House newHouse = new House(num, street + " street");
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(int num, Type type, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(num, type);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(num, type);
                return;
            }
            House newHouse = new House(num, type);
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(string street, Type type, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(street, type);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(street, type);
                return;
            }
            House newHouse = new House(street + " street", type);
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void AddAnywhere(int num, string street, Type type, int position)
        {
            if (position <= 0 || position > size + 1)
            {
                throw new InvalidOperationException("Invalid position.");
            }
            if (position == 1)
            {
                AddToFront(num, street, type);
                return;
            }
            if (position == size + 1)
            {
                AddToBack(num, street, type);
                return;
            }
            House newHouse = new House(num, street + " street", type);
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            newHouse.Next = temp.Next;
            temp.Next = newHouse;
            size++;
        }
        public void RemoveFromFront(out int num, out string street, out Type type)
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Listing Is Empty!");
            }
            num = head.HouseNumber;
            street = head.HouseStreet;
            type = head.HouseType;
            head = head.Next;
            size--;
            if (IsEmpty())
            {
                tail = null;
            }
        }
        public void RemoveFromBack(out int num, out string street, out Type type)
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Listing Is Empty!");
            }
            num = tail.HouseNumber;
            street = tail.HouseStreet;
            type = tail.HouseType;
            House temp = head;
            int i = 1;
            while (i < size - 1)
            {
                temp = temp.Next;
                i++;
            }
            tail = temp;
            tail.Next = null;
            size--;
            if (IsEmpty())
            {
                head = null;
            }
        }
        public void RemoveFromAnywhere(int position, out int num, out string street, out Type type)
        {
            if (position <= 0 || position > size)
            {
                throw new InvalidOperationException("Invalid Position.");
            }
            if (position == 1)
            {
                RemoveFromFront(out num, out street, out type);
            }
            if (position == size)
            {
                RemoveFromBack(out num,out street,out type);
            }
            House temp = head;
            int i = 1;
            while (i < position - 1)
            {
                temp = temp.Next;
                i++;
            }
            num = temp.Next.HouseNumber;
            street = temp.Next.HouseStreet;
            type = temp.Next.HouseType;
            temp.Next = temp.Next.Next;
            size--;
        }
        public bool Search(int num)
        {
            House temp = head;
            while (temp != null)
            {
                if (temp.HouseNumber == num)
                {
                    return true;
                }
                temp = temp.Next;
            }
            return false;
        }
        public bool Search(string street)
        {
            House temp = head;
            while (temp != null)
            {
                if (temp.HouseStreet == street)
                {
                    return true;
                }
                temp= temp.Next;
            }
            return false;
        }
        public bool Search(Type type)
        {
            House temp = head;
            while (temp != null)
            {
                if (temp.HouseType == type)
                {
                    return true;
                }
                temp = temp.Next;
            }
            return false;
        }
        public void DisplayAll()
        {
            House temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("\nHouse Listings Are Empty!");
                return;
            }
            else
            {
                Console.WriteLine("\nAll Listed Houses:  \n===============");
                while (temp != null)
                {
                    Console.WriteLine("\nHouse Listing:  \n---------------");
                    Console.WriteLine($"House Number:  {temp.HouseNumber}");
                    Console.WriteLine($"House Address:  {temp.HouseStreet}");
                    Console.WriteLine($"House Type:  {temp.HouseType.ToString()}");
                    temp = temp.Next;
                }
            }
        }
        public void SearchAndDisplay(int num)
        {
            House temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("\nHouse Listings Are Empty!");
                return;
            }
            else if (Search(num))
            {
                Console.WriteLine($"\nMatch Found For House Number {num}:  \n===============");
                while (temp != null)
                {
                    if (temp.HouseNumber == num)
                    {
                        Console.WriteLine("\nHouse Listing:  \n---------------");
                        Console.WriteLine($"House Number:  {temp.HouseNumber}");
                        Console.WriteLine($"House Address:  {temp.HouseStreet}");
                        Console.WriteLine($"House Type:  {temp.HouseType.ToString()}");
                    }
                    temp = temp.Next;
                }
            }
            else
            {
                Console.WriteLine($"\nMatch For House Number {num} Not Found In Listings.");
            }
        }
        public void SearchAndDisplay(string street)
        {
            House temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("\nHouse Listings Are Empty!");
                return;
            }
            else if (Search(street))
            {
                Console.WriteLine($"\nMatch(es) Found For House Listings On {street}:  \n===============");
                while (temp != null)
                {
                    if (temp.HouseStreet == street)
                    {
                        Console.WriteLine("\nHouse Listing:  \n---------------");
                        Console.WriteLine($"House Number:  {temp.HouseNumber}");
                        Console.WriteLine($"House Address:  {temp.HouseStreet}");
                        Console.WriteLine($"House Type:  {temp.HouseType.ToString()}");
                    }
                    temp = temp.Next;
                }
            }
            else
            {
                Console.WriteLine($"\nNo Matches For House Listings On {street}.");
            }
        }
        public void SearchAndDisplay(Type type)
        {
            House temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("\nHouse Listings Are Empty!");
                return;
            }
            else if (Search(type))
            {
                Console.WriteLine($"\nMatch(es) Found For {type.ToString()} Style House Listings:  \n===============");
                while (temp != null)
                {
                    if (temp.HouseType == type)
                    {
                        Console.WriteLine("\nHouse Listing:  \n---------------");
                        Console.WriteLine($"House Number:  {temp.HouseNumber}");
                        Console.WriteLine($"House Address:  {temp.HouseStreet}");
                        Console.WriteLine($"House Type:  {temp.HouseType.ToString()}");
                    }
                    temp = temp.Next;
                }
            }
            else
            {
                Console.WriteLine($"\nMatches For {type} Style Houses Not Found In Listings.");
            }
        }
        public void ClearListings()
        {
            Console.Write("\nAre you sure you wish to clear listings? (y/n):  ");
            string input = Console.ReadLine().ToLower();
            if (input == "y" || input == "yes" || input == "1")
            {
                while (head != null)
                {
                    head = head.Next;
                }
                tail = null;
            }
        }
    }
}
