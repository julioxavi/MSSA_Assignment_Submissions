﻿namespace Assignment_6_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Part1();
            Part3();
        }
        static void Part1()
        {
            int num;
            string str;
            Type typ;
            HouseListings listings = new HouseListings();
            listings.AddToFront(1001);
            listings.AddToFront(1003);
            listings.AddToBack(1005);
            listings.AddToFront("Blackberry");
            listings.AddToBack("Blueberry");
            listings.AddToBack("Strawberry");
            listings.AddToFront(Type.Mediterranean);
            listings.AddAnywhere(Type.Craftsman, 3);
            listings.AddAnywhere(Type.Tudor, 5);
            listings.AddToFront(2002, "Blackberry");
            listings.AddToBack(2004, Type.Victorian);
            listings.AddToBack(2006, Type.Victorian);
            listings.AddToBack(2008, "Strawberry", Type.Ranch);
            listings.SearchAndDisplay(1003);
            listings.SearchAndDisplay("Strawberry street");
            listings.SearchAndDisplay(Type.Victorian);
            listings.RemoveFromFront(out num, out str, out typ);
            Console.WriteLine($"\n{typ} style house, '{num} {str}', removed from listings.");
            listings.RemoveFromBack(out num, out str, out typ);
            Console.WriteLine($"\n{typ} style house, '{num} {str}', removed from listings.");
            listings.RemoveFromAnywhere(2, out num, out str, out typ);
            Console.WriteLine($"\n{typ} style house, '{num} {str}', removed from listings.");
            listings.DisplayAll();
            listings.ClearListings();
            listings.DisplayAll();
        }
        static void Part3()
        {
            Console.WriteLine("Part 3:  \n===============\n");

            Console.WriteLine("Given an integer array, let's move all 0's to the end while maintaing the order of the non-zero elements!");

            string? userInput = null;
            bool redFlag = true;

            int[] inputArray;

            do
            {
                Console.Write("\nSort Array? (y/n):  ");
                userInput = Console.ReadLine();
                if(userInput == null)
                {
                    Console.WriteLine("\nInvalid Input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            InitializeArray(out inputArray);
                            Console.WriteLine($"\n===============\nInput:  [ {string.Join(", ", inputArray)} ]");
                            SortZeroes(inputArray);
                            Console.WriteLine($"Output:  [ {string.Join(", ", inputArray)} ]\n===============\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("\nInvalid Input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void InitializeArray(out int[] array)
        {
            Random roll = new Random();
            array = new int[roll.Next(1, 21)];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = roll.Next(0, 5);
            }

        }
        static void SortZeroes(int[] array)
        {
            int count = 1;
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i] == 0)
                {
                    while (array[i + count] == 0 && i + count <= array.Length - 2)
                    {
                        count++;
                    }
                    array[i] = array[i + count];
                    array[i + count] = 0;
                    count = 1;
                }
            }
        }
    }
}
