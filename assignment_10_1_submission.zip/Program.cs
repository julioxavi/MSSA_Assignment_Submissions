﻿using System.Text.Json;
using System.Xml.Serialization;

namespace Assignment_10_1
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            //Part1();
            Part2();
        }

        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n_______________\n");

            Console.WriteLine("Let's create a class object of our choice, then serialize and deserialize it in Binary, JSON, and XML format!\n");
            
            string binaryFilePath = @"C:\MSSA\Files\ccad23binarytest.txt";
            string jsonFilePath = @"C:\MSSA\Files\ccad23jsontest.txt";
            string xmlFilePath = @"C:\MSSA\Files\ccad23xmltest.xml";
            Sushi sushiRoll = new Sushi() { Format = "original text", Name = "Tuna Avocado Roll", Ingredients = "Rice, Seaweed, Tuna, Cucumber, Avocado", Price = 5.49, ContainsRawFish = true, IsSpicy = false };
            Console.WriteLine($"Sushi Roll Info:  \n===============\nFormat -> {sushiRoll.Format}\nName -> {sushiRoll.Name}\nIngredients -> {sushiRoll.Ingredients}\nPrice -> {sushiRoll.Price:C}\nContainsRawFish -> {sushiRoll.ContainsRawFish}\nIsSpicy -> {sushiRoll.IsSpicy}\n------------------------------\n");
            FileStream fs;

            //  Serialize Binary Data
            if (File.Exists(binaryFilePath))
            {
                File.Delete(binaryFilePath);
            }
            fs = new FileStream(binaryFilePath, FileMode.CreateNew, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            sushiRoll.Format = "binary";
            sushiRoll.Serialize(bw);
            bw.Close();
            fs.Close();
            Console.WriteLine("Binary data serialized");

            //  Deserialize Binary Data
            Console.WriteLine("\nDeserializing binary data...\n");
            fs = new FileStream(binaryFilePath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            var broll = Sushi.Deserialize(br);
            br.Close();
            fs.Close();
            Console.WriteLine($"Sushi Roll Info:  \n===============\nFormat -> {broll.Format}\nName -> {broll.Name}\nIngredients -> {broll.Ingredients}\nPrice -> {broll.Price:C}\nContainsRawFish -> {broll.ContainsRawFish}\nIsSpicy -> {broll.IsSpicy}\n------------------------------\n");

            //  Serialize JSON Data
            if (File.Exists(jsonFilePath))
            {
                File.Delete(jsonFilePath);
            }
            fs = new FileStream(jsonFilePath, FileMode.CreateNew, FileAccess.Write);
            sushiRoll.Format = "json";
            JsonSerializer.Serialize(fs, sushiRoll);
            fs.Close();
            Console.WriteLine("JSON data serialized");

            //  Deserialize JSON Data
            Console.WriteLine("\nDeserializing JSON data...\n");
            fs = new FileStream(jsonFilePath, FileMode.Open, FileAccess.Read);
            var jroll = JsonSerializer.Deserialize<Sushi>(fs);
            fs.Close();
            Console.WriteLine($"Sushi Roll Info:  \n===============\nFormat -> {jroll.Format}\nName -> {jroll.Name}\nIngredients -> {jroll.Ingredients}\nPrice -> {jroll.Price:C}\nContainsRawFish -> {jroll.ContainsRawFish}\nIsSpicy -> {jroll.IsSpicy}\n------------------------------\n");

            //  Serialize XML Data
            if (File.Exists(xmlFilePath))
            {
                File.Delete(xmlFilePath);
            }
            fs = new FileStream(xmlFilePath, FileMode.CreateNew, FileAccess.Write);
            sushiRoll.Format = "xml";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Sushi));
            xmlSerializer.Serialize(fs, sushiRoll);
            fs.Close();
            Console.WriteLine("XML data serialized");

            //  Deserialize XML data
            Console.WriteLine("\nDeserializing XML data...\n");
            fs = new FileStream(xmlFilePath, FileMode.Open, FileAccess.Read);
            var xroll = (Sushi)xmlSerializer.Deserialize(fs);
            fs.Close();
            Console.WriteLine($"Sushi Roll Info:  \n===============\nFormat -> {xroll.Format}\nName -> {xroll.Name}\nIngredients -> {xroll.Ingredients}\nPrice -> {xroll.Price:C}\nContainsRawFish -> {xroll.ContainsRawFish}\nIsSpicy -> {xroll.IsSpicy}\n------------------------------\n");

            Console.WriteLine("\nHave a nice day!\n");
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n_______________\n");

            Console.WriteLine("Given 'n' pair of parentheses, let's write a function to generate all combinations of well-formed parentheses!\n");

            Console.WriteLine($"Generating parenthesis pairs for 'n = 0':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(0))} ]\n");
            Console.WriteLine($"Generating parenthesis pairs for 'n = 1':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(1))} ]\n");
            Console.WriteLine($"Generating parenthesis pairs for 'n = 2':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(2))} ]\n");
            Console.WriteLine($"Generating parenthesis pairs for 'n = 3':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(3))} ]\n");
            Console.WriteLine($"Generating parenthesis pairs for 'n = 4':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(4))} ]\n");
            Console.WriteLine($"Generating parenthesis pairs for 'n = 5':  \n----------------------------------------\n[ {string.Join(", ", GenerateParenPairs(5))} ]\n");

            Console.WriteLine("\nHave a nice day!\n");
        }
        static string[] GenerateParenPairs(int n, int i = 0)
        {
            if (n < 0)
            {
                throw new ArgumentOutOfRangeException("'n' values must be greater than or equal to zero");
            }
            if (n == 0)
            {
                return new string[] { string.Empty };
            }
            if (n == i)
            {
                return new string[0];
            }

            string[] inside = GenerateParenPairs(i);
            string[] outside = GenerateParenPairs(n - 1 - i);
            string[] remaining = GenerateParenPairs(n, i + 1);

            string[] results = new string[inside.Length * outside.Length + remaining.Length];

            int k = 0;
            foreach (string a in inside)
            {
                foreach (string b in outside)
                {
                    results[k++] = $"({a}){b}";
                }
            }

            Array.Copy(remaining, 0, results, k, remaining.Length);

            return results;
        }
    }

    public class Sushi
    {
        public string Format { get; set; }
        public string Name { get; set; }
        public string Ingredients { get; set; }
        public double Price { get; set; }
        public bool ContainsRawFish { get; set; }
        public bool IsSpicy { get; set; }

        public void Serialize(BinaryWriter bw)
        {
            bw.Write(Format);
            bw.Write(Name);
            bw.Write(Ingredients);
            bw.Write(Price);
            bw.Write(ContainsRawFish);
            bw.Write(IsSpicy);
        }

        public static Sushi Deserialize(BinaryReader br)
        {
            return new Sushi
            {
                Format = br.ReadString(),
                Name = br.ReadString(),
                Ingredients = br.ReadString(),
                Price = br.ReadDouble(),
                ContainsRawFish = br.ReadBoolean(),
                IsSpicy = br.ReadBoolean()
            };
        }
    }
}
