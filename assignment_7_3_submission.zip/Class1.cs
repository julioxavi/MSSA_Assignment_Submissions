﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Assignment_7_3
{
    internal class Node
    {
        public int Data { get; set; }
        public Node left;
        public Node right;
        public Node (int val)
        {
            Data = val;
            left = null;
            right = null;
        }
    }

    class BST
    {
        private Node root;
        public static int InOrderCounter = 0;
        public static int PreOrderCounter = 0;
        public static int PostOrderCounter = 0;
        public Node Root { get { return root; } }
        public BST() { root = null; }
        public void Add(int val)
        {
            Node newNode = new Node(val);
            Node temp = root;
            if (temp == null)
            {
                root = newNode;
            }
            else
            {
                while (temp != null)
                {
                    if (temp.Data == val)
                    {
                        Console.WriteLine("Cannot add duplicate values, value already exists.");
                        break;
                    }
                    else if (val < temp.Data)
                    {
                        if (temp.left == null)
                        {
                            temp.left = newNode;
                            break;
                        }
                        else
                        {
                            temp = temp.left;
                        }
                    }
                    else
                    {
                        if (temp.right == null)
                        {
                            temp.right = newNode;
                            break;
                        }
                        else
                        {
                            temp = temp.right;
                        }
                    }
                }
            }
        }
        public Node InOrderSearch(int val)
        {
            Node temp = root;
            Node result = null;
            InOrderCounter = 0;
            InOrder(temp, val, ref result);
            return result;
        }
        public void InOrder(Node temp, int val, ref Node result)
        {
            InOrderCounter++;
            if (temp != null && result == null)
            {
                InOrder(temp.left, val, ref result);
                if (temp.Data == val)
                {
                    result = temp;
                }
                InOrder(temp.right, val, ref result);
            }
        }
        public Node PreOrderSearch(int val)
        {
            Node temp = root;
            Node result = null;
            PreOrderCounter = 0;
            PreOrder(temp, val, ref result);
            return result;
        }
        public void PreOrder(Node temp, int val, ref Node result)
        {
            PreOrderCounter++;
            if (temp != null && result == null)
            {
                if (temp.Data == val)
                {
                    result = temp;
                }
                PreOrder(temp.left, val, ref result);
                PreOrder(temp.right, val, ref result);
            }
        }
        public Node PostOrderSearch(int val)
        {
            Node temp = root;
            Node result = null;
            PostOrderCounter = 0;
            PostOrder(temp, val, ref result);
            return result;
        }
        public void PostOrder(Node temp, int val, ref Node result)
        {
            PostOrderCounter++;
            if (temp != null && result == null)
            {
                PostOrder(temp.left, val, ref result);
                PostOrder(temp.right, val, ref result);
                if (temp.Data == val)
                {
                    result = temp;
                }
            }
        }
        public void DisplayTree(Node node = null)
        {
            if (root == null)
            {
                Console.WriteLine("(empty tree)");
                return;
            }
            if (node == null)
            {
                node = root;
            }
            Console.WriteLine(node.Data);
            PrintTree(node, "");
        }
        private void PrintTree(Node node, string indent)
        {
            bool hasLeft = node.left != null;
            bool hasRight = node.right != null;

            if (hasRight)
            {
                Console.WriteLine($"{indent}|-- {node.right.Data}");
                PrintTree(node.right, indent + (hasLeft ? "|   " : "    "));
            }
            if (hasLeft)
            {
                Console.WriteLine($"{indent}|__ {node.left.Data}");
                PrintTree(node.left, indent + "    ");
            }
        }
        public int GetInOrderCounter()
        {
            return InOrderCounter;
        }
        public int GetPreOrderCounter()
        {
            return PreOrderCounter;
        }
        public int GetPostOrderCounter()
        {
            return PostOrderCounter;
        }
    }
}
