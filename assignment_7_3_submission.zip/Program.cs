﻿namespace Assignment_7_3
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
        }
        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============\n");
            
            Console.WriteLine("Given a binary search tree (BST) and an integer val, let's find the node in the BST that that's equal to the val and return its subtree!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Search Tree? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            BST tree = RandomBST();
                            int target = RandomTarget();
                            Node targetNode = tree.InOrderSearch(target);
                            Node targetNode2 = tree.PreOrderSearch(target);
                            Node targetNode3 = tree.PostOrderSearch(target);
                            Console.WriteLine($"\nSearching BST for target: {target}...");
                            Console.WriteLine("...\n......\n............");
                            if (targetNode == null)
                            {
                                Console.WriteLine($"Sorry, the target {target} is not present in this BST.\n");
                            }
                            else
                            {
                                Console.WriteLine($"Success! The target {target} is present in this BST.");
                                Console.WriteLine($"\nNow displaying target subtree:  \n==============================");
                                tree.DisplayTree(targetNode);
                                Console.WriteLine($"==============================\n");
                                Console.WriteLine("\nCount of recursive calls for each search type:  \n------------------------------");
                                Console.WriteLine($"In-order search calls: {tree.GetInOrderCounter()}");
                                Console.WriteLine($"Pre-order search calls: {tree.GetPreOrderCounter()}");
                                Console.WriteLine($"Post-order search calls: {tree.GetPostOrderCounter()}");
                                Console.WriteLine("------------------------------\n");
                            }
                            Console.WriteLine("Displaying full BST:  \n******************************");
                            tree.DisplayTree();
                            Console.WriteLine("\n******************************\n");
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------");
        }
        static BST RandomBST()
        {
            Random roll = new Random();
            BST tree = new BST();
            int len = roll.Next(64);
            List<int> dups = new List<int>();
            int num;
            for (int i = 0; i < len; i++)
            {
                num = roll.Next(10, 100);
                if (dups.Contains(num)) { continue; }
                dups.Add(num);
                tree.Add(num);
            }
            return tree;
        }
        static int RandomTarget()
        {
            Random roll = new Random();
            int target = roll.Next(10, 100);
            return target;
        }
    }
}
