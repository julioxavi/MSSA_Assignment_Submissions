﻿using System.Text;
namespace Week_6_Challenge_Labs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Given an (n X n) 2D matrix representing an image, let's rotate the image clockwise by 90 degrees in-place!\n");

            int[,] example1 = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int[,] example2 = { { 5, 1, 9, 11 }, { 2, 4, 8, 10 }, { 13, 3, 6, 7 }, { 15, 14, 12, 16 } };
            int[,] example3 = { { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } };

            Console.WriteLine("Example 1 Matrix:  ");
            DisplayMatrix(example1);
            RotateMatrix(example1);
            Console.WriteLine("Rotated Matrix:  ");
            DisplayMatrix(example1);

            Console.WriteLine("Example 2 Matrix:  ");
            DisplayMatrix(example2);
            RotateMatrix(example2);
            Console.WriteLine("Rotated Matrix:  ");
            DisplayMatrix(example2);

            Console.WriteLine("Example 3 Matrix:  ");
            DisplayMatrix(example3);
            RotateMatrix(example3);
            Console.WriteLine("Rotated Matrix:  ");
            DisplayMatrix(example3);

            int[,] matrix;
            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Intitialize and rotate matrix? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Initialize2DArray(out matrix);
                            Console.WriteLine("Initialized Matrix:  ");
                            DisplayMatrix(matrix);
                            RotateMatrix(matrix);
                            Console.WriteLine("Rotated Matrix:  ");
                            DisplayMatrix(matrix);
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

        }
        static void DisplayMatrix(int[,] matrix)
        {
            Console.WriteLine("".PadRight(matrix.GetLength(0) * 6, '_'));
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"|-{matrix[i, j].ToString().PadLeft(2, '-')}-");
                }
                Console.WriteLine("|");
            }
            Console.WriteLine("".PadRight(matrix.GetLength(0) * 6, '\u203E'));
        }
        static void RotateMatrix(int[,] matrix)
        {
            int len = matrix.GetLength(0) - 1;
            int depth = 0;
            int counter = 0;
            int tempx, tempz, tempy;

            while(depth < len)
            {
                while (counter < len - depth)
                {
                    tempx = matrix[depth + counter, len];
                    tempz = matrix[len, len - counter];
                    tempy = matrix[len - counter, depth];
                    matrix[depth + counter, len] = matrix[depth, depth + counter];
                    matrix[len, len - counter] = tempx;
                    matrix[len - counter, depth] = tempz;
                    matrix[depth, depth + counter] = tempy;
                    counter++;
                }
                counter = 0;
                depth++;
                len--;
            }
            
        }
        static void Initialize2DArray(out int[,] matrix)
        {
            Random random = new Random();
            int size = random.Next(21);
            matrix = new int[size, size];
            for(int i = 0; i < size; i++)
            {
                for(int j = 0; j < size; j++)
                {
                    matrix[i, j] = random.Next(100);
                }
            }
        }
    }
}
