﻿using System.Globalization;
using System.Linq;
using System.Security.AccessControl;
namespace Assignment_11_2
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }

        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n______________________________\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random prices and find optimal buy/sell days for max profit? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.WriteLine("\n------------------------------");

                            var prices = GenerateRandomPrices();
                            Console.WriteLine($"The prices are: [ {string.Join(", ", prices.Select(p => p.ToString("C")))} ]");

                            int[] days = Enumerable.Range(1, prices.Length).ToArray();
                            Array.Sort(prices, days);

                            int profit = ReturnMaxProfit(prices, days, out int buyPrice, out int buyDay, out int sellPrice, out int sellDay);
                            if (profit == 0)
                            {
                                Console.WriteLine("*****\nWith these prices, there are no good days to buy and sell for profit.\n*****");
                            }
                            else
                            {
                                Console.WriteLine($"The maximum profit is: {profit:C}");
                                Console.WriteLine($"The buy price is: {buyPrice:C} on day {buyDay}");
                                Console.WriteLine($"The sell price is: {sellPrice:C} on day {sellDay}");
                            }
                            
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            

            Console.WriteLine("\nHave a nice day!\n");
        }
        static int[] GenerateRandomPrices()
        {
            Random r = new Random();
            int[] prices = new int[r.Next(3, 10)];
            for (int i = 0; i < prices.Length; i++)
            {
                prices[i] = r.Next(1, 21);
            }
            return prices;
        }
        static int ReturnMaxProfit(int[] prices, int[] days, out int buyPrice, out int buyDay, out int sellPrice, out int sellDay)
        {
            int profit = 0;
            buyPrice = -1;
            buyDay = -1;
            sellPrice = -1;
            sellDay = -1;
            for (int i = 0; i < prices.Length; i++)
            {
                if (prices[prices.Length - 1] - prices[i] <= profit)
                {
                    break;
                }
                for (int j = prices.Length - 1; j >= 0; j--)
                {
                    if (prices[j] - prices[i] <= profit)
                    {
                        break;
                    }
                    if (days[j] > days[i])
                    {
                        profit = prices[j] - prices[i];
                        buyPrice = prices[i];
                        buyDay = days[i];
                        sellPrice = prices[j];
                        sellDay = days[j];
                        break;
                    }
                }
            }
            return profit;
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n______________________________\n");

            Console.WriteLine("Given the head of a singly linked list, let's reverse the list and return the reversed list!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random singly linked list and reverse it? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            var list = GenerateRandomLinkedListS();
                            Console.WriteLine("\n------------------------------");
                            Console.Write("Input List:\t");
                            list.Display();
                            ReverseLinkedListS(ref list);
                            Console.Write("Reversed List:\t");
                            list.Display();
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static LinkedListS GenerateRandomLinkedListS()
        {
            Random r = new Random();
            int len = r.Next(2, 8);
            LinkedListS list = new LinkedListS();
            int[] nums = new int[len];
            for (int i = 0; i < len; i++)
            {
                nums[i] = r.Next(0, 21);
            }
            nums.Sort();
            for (int i = 0; i < len; i++)
            {
                list.AddLast(nums[i]);
            }
            return list;
        }
        static void ReverseLinkedListS(ref LinkedListS list)
        {
            for (int i = 2; i < list.Size + 1; i++)
            {
                list.AddFirst(list.RemoveAnywhere(i));
            }
        }
    }
    class Node
    {
        public int Value { get; set; }
        public Node Next;
        public Node(int val)
        {
            Value = val;
            Next = null;
        }
    }
    class LinkedListS
    {
        private Node head;
        private Node tail;
        private int size;
        public int Size { get { return size; } }

        public LinkedListS()
        {
            head = null;
            tail = null;
            size = 0;
        }

        public bool IsEmpty()
        {
            return size == 0;
        }

        public void AddFirst(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                node.Next = head;
                head = node;
            }
            size++;
        }

        public void AddLast(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                tail.Next = node;
                tail = node;
            }
            size++;
        }

        public void AddAnywhere(int val, int pos)
        {
            if (pos <= 0 || pos > size + 1)
            {
                throw new InvalidOperationException("Invalid Position.");
            }
            if (pos == 1)
            {
                AddFirst(val);
                return;
            }
            if (pos == size + 1)
            {
                AddLast(val);
                return;
            }
            Node node = new Node(val);
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.Next;
                i++;
            }
            node.Next = temp.Next;
            temp.Next = node;
            size++;
        }

        public int RemoveFirst()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = head.Value;
            head = head.Next;
            size--;
            if (IsEmpty())
            {
                tail = null;
            }
            return val;
        }

        public int RemoveLast()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = tail.Value;
            Node node = head;
            int i = 1;
            while (i < size - 1)
            {
                node = node.Next;
                i++;
            }
            tail = node;
            node.Next = null;
            size--;
            if (IsEmpty())
            {
                head = null;
            }
            return val;
        }

        public int RemoveAnywhere(int pos)
        {
            if (pos <= 0 || pos > size)
            {
                throw new InvalidOperationException("List is empty.");
            }
            if (pos == 1)
            {
                return RemoveFirst();
            }
            if (pos == size)
            {
                return RemoveLast();
            }
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.Next;
                i++;
            }
            int val = temp.Next.Value;
            temp.Next = temp.Next.Next;
            size--;
            return val;
        }

        public bool Search(int val)
        {
            Node temp = head;
            while (temp != null)
            {
                if (temp.Value == val)
                {
                    return true;
                }
                temp = temp.Next;
            }
            return false;
        }

        public void Display()
        {
            Node temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("List is empty.");
                return;
            }
            else
            {
                Console.Write("{ ");
                while (temp != null)
                {
                    if (temp.Next == null)
                    {
                        Console.Write($"{temp.Value}");
                        temp = temp.Next;
                    }
                    else
                    {
                        Console.Write($"{temp.Value} -> ");
                        temp = temp.Next;
                    }
                }
                Console.WriteLine(" }");
            }
        }
    }
}
