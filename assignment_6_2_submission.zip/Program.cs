﻿using System.Net.Http.Headers;
using System.Runtime.InteropServices;

namespace Assignment_6_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }
        static void Part1()
        {
            Console.WriteLine("***************\nGAS STATION 8/12:  \"Your Favorite Gas Station\"\n***************\n");

            GAStank<int> tank = new GAStank<int>(200);
            tank.Fill(1);
            tank.Display();
            Console.WriteLine("Cusomer vehicle:  SUV\nRequesting 40 units of gas");
            int SUVtank = 1;
            int customerRequest = 40;
            Console.WriteLine($"Customer tank before refueling:  {SUVtank}");
            for (int i = SUVtank; i < customerRequest; i++)
            {
                if (tank.IsEmpty()) break;
                SUVtank += tank.Pop();
            }
            Console.WriteLine($"Customer tank after refueling:  {SUVtank}");
            tank.Display();
            Console.WriteLine("Cusomer vehicle:  HatchBack\nRequesting 20 units of gas");
            int HBtank = 4;
            customerRequest = 20;
            Console.WriteLine($"Customer tank before refueling:  {HBtank}");
            for (int i = HBtank; i < customerRequest; i++)
            {
                if (tank.IsEmpty()) break;
                HBtank += tank.Pop();
            }
            Console.WriteLine($"Customer tank after refueling:  {HBtank}");
            tank.Display();
            Console.WriteLine("Cusomer vehicle:  18wheeler\nRequesting 150 units of gas");
            int EWtank = 30;
            customerRequest = 150;
            Console.WriteLine($"Customer tank before refueling:  {EWtank}");
            for (int i = EWtank; i < customerRequest; i++)
            {
                if (tank.IsEmpty()) break;
                EWtank += tank.Pop();
            }
            Console.WriteLine($"Customer tank after refueling:  {EWtank}");
            tank.Display();
            Console.WriteLine("Refueling Gas Tank:  100 units");
            customerRequest = 180;
            tank.Display();
            for (int i = 0; i < customerRequest; i++)
            {
                if (tank.IsFull()) break;
                tank.Push(1);
            }
            tank.Display();
            Console.WriteLine("Cusomer vehicle:  18wheeler\nRequesting 150 units of gas");
            customerRequest = 150;
            Console.WriteLine($"Customer tank before refueling:  {EWtank}");
            for (int i = EWtank; i < customerRequest; i++)
            {
                if (tank.IsEmpty()) break;
                EWtank += tank.Pop();
            }
            Console.WriteLine($"Customer tank after refueling:  {EWtank}");
            tank.Display();
        }
        //  with arrays of very large sizes, the products are sometimes negative numbers; probably a limitation of the int32 type.
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============\n");

            Console.WriteLine("Given an integer array, let's return an array where the answer[i] is equal to product of all the elements in the given array except given[i]!\n");

            string? userInput = null;
            bool redFlag = true;

            int[] inputArray;
            int[] outputArray;

            do
            {
                Console.Write("Create product array from random input array? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid Input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            InitializeArray(out inputArray);
                            ProductArray(inputArray, out outputArray);
                            Console.WriteLine($"\n===============\nInput:  [ {string.Join(", ", inputArray)} ]");
                            Console.WriteLine($"Output:  [ {string.Join(", ", outputArray)} ]\n===============\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid Input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void InitializeArray(out int[] array)
        {
            Random roll = new Random();
            array = new int[roll.Next(1, 10)];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = roll.Next(21);
            }
        }
        //  O(2n) -> O(n)
        static void ProductArray(int[] input, out int[] output)
        {
            output = new int[input.Length];
            int leftProduct = 1;
            int rightProduct = 1;
            if (input.Length <= 1)
            {
                output = input;
            }
            else
            {
                for (int i = 0; i < input.Length; i++)
                {
                    output[i] = leftProduct;
                    leftProduct *= input[i];
                }
                for (int j = input.Length - 1; j >= 0; j--)
                {
                    output[j] *= rightProduct;
                    rightProduct *= input[j];
                }
            }
        }
    }
}
