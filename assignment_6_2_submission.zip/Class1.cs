﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_6_2
{
    internal class GAStank<T>   //  G.A.S. -> Generic Array Stack :)
    {
        private T[] data;
        private int top;
        public GAStank(int size)
        {
            data = new T[size];
            top = -1;
        }
        public bool IsEmpty()
        {
            return top == -1;
        }
        public bool IsFull()
        {
            return top == data.Length - 1;
        }
        public void Push(T fuel)
        {
            if (IsFull())
            {
                throw new InvalidOperationException("Tank is Full!");
            }
            else
            {
                top++;
                data[top] = fuel;
            }
        }
        public void Fill(T fuel)
        {
            while (!IsFull())
            {
                top++;
                data[top] = fuel;
            }
        }
        public T Pop()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Tank is Empty!");
            }
            T fuel = data[top];
            top--;
            return fuel;
        }
        public T Peek()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Tank is Empty!");
            }
            return data[top];
        }
        public void Display()
        {
            if (IsEmpty())
            {
                Console.WriteLine("Tank is Empty!");
            }
            if (IsFull())
            {
                Console.WriteLine("Tank is Full!");
            }
            Console.WriteLine($"Units of Gas in GASTANK:  {top + 1}/{data.Length}");
        }
    }
}
