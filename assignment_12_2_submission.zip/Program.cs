﻿using System.ComponentModel;

namespace Assignment_12_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Part 1:  \n______________________________\n");
            Console.WriteLine("Given the head of a linked list and interger 'val', let's remove all nodes where the value is equal to 'val' and then return the new head!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random singly linked list and target value, then remove target nodes? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.WriteLine("\n------------------------------");
                            (Node listHead, int targetValue) = GenerateRandomSLLAndValue();
                            if (listHead == null)
                            {
                                Console.WriteLine($"Input Head Node:  null");
                            }
                            else
                            {
                                Console.WriteLine($"Input Head Node:  {listHead.val}");
                            }
                            Console.Write($"Input Singly Linked List:  ");
                            DisplaySLL(listHead);
                            Console.WriteLine($"Target Value:  {targetValue}");
                            Node newListHead = RemoveNodes(listHead, targetValue);
                            if (listHead == null)
                            {
                                Console.WriteLine($"Output Head Node:  null");
                            }
                            else
                            {
                                Console.WriteLine($"Output Head Node:  {newListHead.val}");
                            }
                            Console.Write($"Output Singly Linked List:  ");
                            DisplaySLL(newListHead);
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static void DisplaySLL(Node head)
        {
            if (head == null)
            {
                Console.WriteLine("{  }");
            }
            else if (head.next == null)
            {
                Console.WriteLine($"{{ {head.val} }}");
            }
            else
            {
                Node temp = head;
                while (temp != null)
                {
                    if (temp == head)
                    {
                        Console.Write($"{{ {temp.val} -> ");
                    }
                    else if (temp.next == null)
                    {
                        Console.WriteLine($"{temp.val} }}");
                    }
                    else
                    {
                        Console.Write($"{temp.val} -> ");
                    }
                    temp = temp.next;
                }
            }
        }
        static (Node, int) GenerateRandomSLLAndValue()
        {
            Random r = new Random();
            int val = 0;
            SinglyLinkedList list = new SinglyLinkedList();
            for (int i = 0; i < r.Next(21); i++)
            {
                val = r.Next(10);
                list.AddLast(val);
            }
            val = r.Next(10);
            return (list.Head, val);
        }
        static Node RemoveNodes(Node head, int val)
        {
            Node temp = head;
            Node prev = null;
            while(temp != null)
            {
                if (temp == head)
                {
                    if (temp.val == val)
                    {
                        head = head.next;
                        temp = temp.next;
                    }
                    else
                    {
                        temp = temp.next;
                        prev = head;
                    }
                }
                else if (temp.next == null)
                {
                    if (temp.val == val)
                    {
                        temp = temp.next;
                        prev.next = null;
                    }
                    else
                    {
                        temp = temp.next;
                        prev = prev.next;
                    }
                }
                else
                {
                    if (temp.val == val)
                    {
                        temp = temp.next;
                        prev.next = prev.next.next;
                    }
                    else
                    {
                        temp = temp.next;
                        prev = prev.next;
                    }
                }
            }
            return head;
        }
    }
    class Node
    {
        public int val;
        public Node next;
        public Node(int val)
        {
            this.val = val;
            next = null;
        }
    }
    class SinglyLinkedList
    {
        private Node head;
        public Node Head { get { return head; } }
        private Node tail;
        public Node Tail { get { return tail; } }
        private int size;
        public int Size { get { return size; } }
        public SinglyLinkedList()
        {
            head = null;
            tail = null;
            size = 0;
        }
        public bool IsEmpty()
        {
            return size == 0;
        }
        public void AddFirst(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                node.next = head;
                head = node;
            }
            size++;
        }
        public void AddLast(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                tail.next = node;
                tail = node;
            }
            size++;
        }
        public void AddAnywhere(int val, int pos)
        {
            if (pos <= 0 || pos > size + 1)
            {
                throw new InvalidOperationException("Invalid Position.");
            }
            if (pos == 1)
            {
                AddFirst(val);
                return;
            }
            if (pos == size + 1)
            {
                AddLast(val);
                return;
            }
            Node node = new Node(val);
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.next;
                i++;
            }
            node.next = temp.next;
            temp.next = node;
            size++;
        }
        public int RemoveFirst()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = head.val;
            head = head.next;
            size--;
            if (IsEmpty())
            {
                tail = null;
            }
            return val;
        }
        public int RemoveLast()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = tail.val;
            Node node = head;
            int i = 1;
            while (i < size - 1)
            {
                node = node.next;
                i++;
            }
            tail = node;
            node.next = null;
            size--;
            if (IsEmpty())
            {
                head = null;
            }
            return val;
        }
        public int RemoveAnywhere(int pos)
        {
            if (pos <= 0 || pos > size)
            {
                throw new InvalidOperationException("List is empty.");
            }
            if (pos == 1)
            {
                return RemoveFirst();
            }
            if (pos == size)
            {
                return RemoveLast();
            }
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.next;
                i++;
            }
            int val = temp.next.val;
            temp.next = temp.next.next;
            size--;
            return val;
        }
        public bool Search(int val)
        {
            Node temp = head;
            while (temp != null)
            {
                if (temp.val == val)
                {
                    return true;
                }
                temp = temp.next;
            }
            return false;
        }
        public void Display()
        {
            Node temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("List is empty.");
                return;
            }
            else
            {
                Console.Write("{ ");
                while (temp != null)
                {
                    if (temp.next == null)
                    {
                        Console.Write($"{temp.val}");
                        temp = temp.next;
                    }
                    else
                    {
                        Console.Write($"{temp.val} -> ");
                        temp = temp.next;
                    }
                }
                Console.WriteLine(" }");
            }
        }
    }
}
