﻿using System.Text;

namespace Assignment_7_1
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }
        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============\n");

            Console.WriteLine("Let's take an array of exam sort and use selection sort to sort them in ascending order!");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("\nSort Exam Scores? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            InitializeScores(out int[] scores);
                            Console.WriteLine($"\n==============================\nUnsorted Exam Scores:  [ {string.Join(", ", scores)} ]");
                            SelectionSortScores(scores);
                            Console.WriteLine($"Sorted Exam Scores:  [ {string.Join(", ", scores)} ]\n==============================");
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n-------------------------------\n");
        }
        static void InitializeScores(out int[] scores)
        {
            Random roll = new Random();
            int len = roll.Next(5, 16);
            scores = new int[len];
            for (int i = 0; i < len; i++)
            {
                scores[i] = roll.Next(50, 101);
            }
        }
        static void SelectionSortScores(int[] scores)
        {
            int minPos;
            int temp = 0;
            for (int i = 0; i < scores.Length - 1; i++)
            {
                minPos = i;
                for (int j = i + 1; j < scores.Length; j++)
                {
                    if (scores[j] < scores[minPos])
                    {
                        minPos = j;
                    }
                }
                if (minPos != i)
                {
                    temp = scores[i];
                    scores[i] = scores[minPos];
                    scores[minPos] = temp;
                }
            }
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============\n");

            Console.WriteLine("Let's take two words and merge them together by adding their letters in alternating order!");

            string ex1Word1 = "abc";
            string ex1Word2 = "pqr";
            string ex1Word3;
            Console.WriteLine($"\nInput:  Word 1:  \"{ex1Word1}\"\n\tWord 2:  \"{ex1Word2}\"");
            ex1Word3 = MergeWords(ex1Word1, ex1Word2);
            Console.WriteLine($"Output: Word 3:  \"{ex1Word3}\"");

            string ex2Word1 = "ab";
            string ex2Word2 = "pqrs";
            string ex2Word3;
            Console.WriteLine($"\nInput:  Word 1:  \"{ex2Word1}\"\n\tWord 2:  \"{ex2Word2}\"");
            ex2Word3 = MergeWords(ex2Word1, ex2Word2);
            Console.WriteLine($"Output: Word 3:  \"{ex2Word3}\"");

            string word1;
            string word2;
            string word3;

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("\nMerge Random Words? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "1":
                        case "yes":
                        case "y":
                            word1 = RandomWord();
                            word2 = RandomWord();
                            word3 = MergeWords(word1, word2);
                            Console.WriteLine($"\n==============================\nInput:  Word 1 -> \"{word1}\"\n\tWord 2 -> \"{word2}\"");
                            Console.WriteLine($"Output: Word 3 -> \"{word3}\"\n==============================");
                            break;
                        case "0":
                        case "no":
                        case "n":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n-------------------------------\n");
        }
        static string RandomWord()
        {
            Random roll = new Random();
            const string alphabet = "abcdefghijklmnopqrstuvwxyz";
            int len = roll.Next(3, 10);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < len; i++)
            {
                sb.Append(alphabet[roll.Next(alphabet.Length)]);
            }
            return sb.ToString();
        }
        static string MergeWords(string word1, string word2)
        {
            StringBuilder sb = new StringBuilder();

            int i = 0;
            int j = 0;

            while (i < word1.Length || j < word2.Length)
            {
                if (i < word1.Length && j < word2.Length)
                {
                    sb.Append(word1[i]);
                    sb.Append(word2[j]);
                    i++;
                    j++;
                }
                else if (i < word1.Length && j >= word2.Length)
                {
                    sb.Append(word1.Substring(i));
                    break;
                }
                else if (i >= word1.Length && j < word2.Length)
                {
                    sb.Append(word2.Substring(j));
                    break;
                }
                else
                {
                    throw new Exception("Unexpected error.");
                }
            }
            return sb.ToString();
        }
    }
}
