﻿using System.Text;

namespace Assignment_12_1
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }
        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n______________________________");

            Console.WriteLine("Given two strings \"ransomNote\" and \"magazine\", let's create a program that returns true or false whether or not ransomNote can be constructed by using the letters from magazine!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random strings and check if ransom note can be constructed? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "1":
                        case "yes":
                        case "y":
                            string magazine = GenerateRandomMagazine();
                            string ransomNote = GenerateRandomRansomNote();
                            Console.WriteLine("\n------------------------------");
                            Console.WriteLine($"Magazine:  {magazine}");
                            Console.WriteLine($"Ransom Note:  {ransomNote}");
                            Console.WriteLine($"Can Construct?:  {CanConstructRansomNote(ransomNote, magazine)}");
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "0":
                        case "no":
                        case "n":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static string GenerateRandomRansomNote()
        {
            Random r = new Random();
            char[] letters = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < r.Next(1, 10); i++)
            {
                sb.Append(letters[r.Next(0, letters.Length)]);
            }
            return sb.ToString();
        }
        static string GenerateRandomMagazine()
        {
            Random r = new Random();
            char[] letters = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < r.Next(50, 100); i++)
            {
                sb.Append(letters[r.Next(0, letters.Length)]);
            }
            return sb.ToString();
        }
        static bool CanConstructRansomNote(string ransomNote, string magazine)
        {
            Dictionary<char, int> lettersOccur = new Dictionary<char, int>();
            foreach (char letter in magazine)
            {
                if (lettersOccur.ContainsKey(letter))
                {
                    lettersOccur[letter]++;
                }
                else
                {
                    lettersOccur[letter] = 1;
                }
            }
            foreach (char letter in ransomNote)
            {
                if (lettersOccur.ContainsKey(letter))
                {
                    if (lettersOccur[letter] > 0)
                    {
                        lettersOccur[letter]--; 
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n______________________________");

            Console.WriteLine("Given the head of a singly linked list, let's create a program that returns true if it is a palindrome, and false otherwise!\n");

            SLL list1 = new SLL();
            SLL list2 = new SLL();
            SLL list3 = new SLL();
            SLL list4 = new SLL();
            SLL list5 = new SLL();

            list1.AddLast(1);
            list1.AddLast(2);
            list1.AddLast(2);
            list1.AddLast(1);

            list2.AddLast(1);
            list2.AddLast(2);

            list3.AddLast(1);
            list3.AddLast(2);
            list3.AddLast(3);
            list3.AddLast(4);
            list3.AddLast(5);
            list3.AddLast(4);
            list3.AddLast(3);
            list3.AddLast(2);
            list3.AddLast(1);

            list4.AddLast(1);
            list4.AddLast(1);
            list4.AddLast(2);
            list4.AddLast(2);
            list4.AddLast(3);
            list4.AddLast(3);

            list5.AddLast(1);
            list5.AddLast(8);
            list5.AddLast(3);
            list5.AddLast(2);
            list5.AddLast(4);
            list5.AddLast(5);
            list5.AddLast(7);
            list5.AddLast(6);
            list5.AddLast(9);

            Console.WriteLine("\n------------------------------");
            Console.Write("List 1:  ");
            list1.Display();
            Console.WriteLine($"Is Palindrome?:  {IsPalindrome(list1)}");
            Console.WriteLine("------------------------------\n");

            Console.WriteLine("\n------------------------------");
            Console.Write("List 2:  ");
            list2.Display();
            Console.WriteLine($"Is Palindrome?:  {IsPalindrome(list2)}");
            Console.WriteLine("------------------------------\n");

            Console.WriteLine("\n------------------------------");
            Console.Write("List 3:  ");
            list3.Display();
            Console.WriteLine($"Is Palindrome?:  {IsPalindrome(list3)}");
            Console.WriteLine("------------------------------\n");

            Console.WriteLine("\n------------------------------");
            Console.Write("List 4:  ");
            list4.Display();
            Console.WriteLine($"Is Palindrome?:  {IsPalindrome(list4)}");
            Console.WriteLine("------------------------------\n");

            Console.WriteLine("\n------------------------------");
            Console.Write("List 5:  ");
            list5.Display();
            Console.WriteLine($"Is Palindrome?:  {IsPalindrome(list5)}");
            Console.WriteLine("------------------------------\n");

            Console.WriteLine("\nHave a nice day!\n");
        }
        static bool IsPalindrome(SLL list)
        {
            while (!list.IsEmpty())
            {
                int a = list.RemoveFirst();
                if (!list.IsEmpty())
                {
                    int b = list.RemoveLast();
                    if (a != b)
                    {
                        return false;
                    }
                }  
            }
            return true;
        }
    }
    class Node
    {
        public int Value { get; set; }
        public Node Next;
        public Node(int val)
        {
            Value = val;
            Next = null;
        }
    }
    class SLL
    {
        private Node head;
        private Node tail;
        private int size;
        public int Size { get { return size; } }
        public SLL()
        {
            head = null;
            tail = null;
            size = 0;
        }
        public bool IsEmpty()
        {
            return size == 0;
        }
        public void AddFirst(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                node.Next = head;
                head = node;
            }
            size++;
        }
        public void AddLast(int val)
        {
            Node node = new Node(val);
            if (IsEmpty())
            {
                head = node;
                tail = node;
            }
            else
            {
                tail.Next = node;
                tail = node;
            }
            size++;
        }
        public void AddAnywhere(int val, int pos)
        {
            if (pos <= 0 || pos > size + 1)
            {
                throw new InvalidOperationException("Invalid Position.");
            }
            if (pos == 1)
            {
                AddFirst(val);
                return;
            }
            if (pos == size + 1)
            {
                AddLast(val);
                return;
            }
            Node node = new Node(val);
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.Next;
                i++;
            }
            node.Next = temp.Next;
            temp.Next = node;
            size++;
        }
        public int RemoveFirst()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = head.Value;
            head = head.Next;
            size--;
            if (IsEmpty())
            {
                tail = null;
            }
            return val;
        }
        public int RemoveLast()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("List is empty.");
            }
            int val = tail.Value;
            Node node = head;
            int i = 1;
            while (i < size - 1)
            {
                node = node.Next;
                i++;
            }
            tail = node;
            node.Next = null;
            size--;
            if (IsEmpty())
            {
                head = null;
            }
            return val;
        }
        public int RemoveAnywhere(int pos)
        {
            if (pos <= 0 || pos > size)
            {
                throw new InvalidOperationException("List is empty.");
            }
            if (pos == 1)
            {
                return RemoveFirst();
            }
            if (pos == size)
            {
                return RemoveLast();
            }
            Node temp = head;
            int i = 1;
            while (i < pos - 1)
            {
                temp = temp.Next;
                i++;
            }
            int val = temp.Next.Value;
            temp.Next = temp.Next.Next;
            size--;
            return val;
        }
        public bool Search(int val)
        {
            Node temp = head;
            while (temp != null)
            {
                if (temp.Value == val)
                {
                    return true;
                }
                temp = temp.Next;
            }
            return false;
        }
        public void Display()
        {
            Node temp = head;
            if (IsEmpty())
            {
                Console.WriteLine("List is empty.");
                return;
            }
            else
            {
                Console.Write("{ ");
                while (temp != null)
                {
                    if (temp.Next == null)
                    {
                        Console.Write($"{temp.Value}");
                        temp = temp.Next;
                    }
                    else
                    {
                        Console.Write($"{temp.Value} -> ");
                        temp = temp.Next;
                    }
                }
                Console.WriteLine(" }");
            }
        }
    }
}
