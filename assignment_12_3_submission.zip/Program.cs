﻿using System.Runtime.InteropServices;
using System.Text;

namespace Assignment_12_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Part 1:  \n______________________________\n");

            Console.WriteLine("Given a string of letters, let's remove all adjacent and equal letters and return the resulting string!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random string and remove duplicates? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.WriteLine("\n------------------------------");
                            string s = GenerateRandomString();
                            Console.WriteLine($"Input string:  {s}");
                            string z = RemoveDuplicates(s);
                            Console.WriteLine($"Output string: {z}");
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static string GenerateRandomString()
        {
            Random r = new Random();
            string s1, s2;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < r.Next(25); i++)
            {
                sb.Append((char)r.Next('a', 'z' + 1));
            }
            s1 = sb.ToString();
            for (int i = 0; i < sb.Length / 2; i++)
            {
                sb.Remove(r.Next(0, sb.Length - i), 1);
            }
            s2 = sb.ToString();
            sb.Clear();
            int len = s1.Length + s2.Length;
            int k = 0;
            int l = 0;
            while (sb.Length < len)
            {
                k = r.Next(0, s1.Length);
                sb.Append(s1[k]);
                s1.Remove(k, 1);
                if (s2.Length != 0)
                {
                    l = r.Next(0, s2.Length);
                    sb.Append(s2[l]);
                    s2.Remove(l, 1);
                }
            }
            return sb.ToString();
        }
        static string RemoveDuplicates(string s)
        {
            int i = 0;
            int j = i + 1;
            bool removedDupes = false;
            while (i < s.Length - 1)
            {
                if (s[i] == s[j])
                {
                    s = s.Remove(i, 2);
                    removedDupes = true;
                    break;
                }
                i++;
                j++;
            }
            if (removedDupes)
            {
                s = RemoveDuplicates(s);
            }
            return s;
        }
    }
}
