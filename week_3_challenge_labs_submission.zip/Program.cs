﻿namespace Week3ChallengLabs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Part1();
            //Part2();
            //Part3();
            //Part4();
        }

        //      ============================== Part 1 ==============================
        static void Part1()
        {
            Console.WriteLine("Part 1:  ");
            Console.WriteLine("\n".PadLeft(15, '='));

            Console.WriteLine("Let's write a method that checks if a given string is a palindrome!\n");

            string example1 = "eye";
            string example2 = "home";
            string input = string.Empty;
            string? userInput = null;
            bool redFlag = false;

            Console.WriteLine($"The following method will be checking if an inputed string is a palindrome or not.  \nFor example:  \n\n\tIsPalindrome(\"eye\") -> {IsPalindrome(example1)}\n\tIsPalindrome(\"home\") -> {IsPalindrome(example2)}\n");
            do
            {
                do
                {
                    Console.Write("Please enter a string to check if it is a palindrome:  ");
                    userInput = Console.ReadLine();
                    redFlag = userInput != null ? false : true;
                    if (redFlag)
                    {
                        Console.WriteLine("Invalid input.");
                    }
                    else
                    {
                        input = userInput;
                    }
                } while (redFlag);

                Console.WriteLine($"\nIs the string \"{input}\" a palindrome?");
                if (IsPalindrome(input))
                {
                    Console.WriteLine($"Yes!  \"{input}\" is a palindrome!");
                }
                else
                {
                    Console.WriteLine($"No...\"{input}\" is not a palindrome.");
                }

                Console.Write("\nDo you want to enter another string? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput == "yes" || userInput == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\nHave a nice day!");
            Console.WriteLine("\n".PadLeft(36, '-'));
        }

        static bool IsPalindrome(string s)
        {
            char[] chars = s.ToLower().Trim().ToCharArray();
            int len = chars.Length;
            int j = len - 1;
            bool isPal = false;
            for (int i = 0; i < len; i++)
            {
                if (i >= j)
                {
                    isPal = true;
                    break;
                }
                else
                {
                    if (chars[i] == chars[j])
                    {
                        j--;
                    }
                    else
                    {
                        isPal = false;
                        break;
                    }
                }
            }
            return isPal;
        }

        //      ============================== Part 2 ==============================
        static void Part2()
        {
            Console.WriteLine("Part 2:  ");
            Console.WriteLine("\n".PadLeft(15, '='));

            Console.WriteLine("Let's write a method which returns the sum of all digits (assuming they are all single digits) in a given string!\n");

            string example1 = "1q2w3e";
            string example2 = "L0r3m.1p5um";
            string example3 = "";

            Console.WriteLine($"The following method will be returning the sum of all digits in an inputed string.  " +
                $"\nFor example:  " +
                $"\n\n\tSumDigitsInString(\"{example1}\") -> {SumDigitsInString(example1)}" +
                $"\n\tSumDigitsInString(\"{example2}\") -> {SumDigitsInString(example2)}" +
                $"\n\tSumDigitsInString(\"{example3}\") -> {SumDigitsInString(example3)}\n");

            string? userInput = null;
            string str = "";
            int result = 0;
            bool redFlag = false;

            do
            {
            inputString:
                Console.Write("Please enter a string of random characters:  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    str = userInput;
                    result = SumDigitsInString(str);
                    Console.WriteLine($"The sum of all digits in string \"{str}\" is:  {result}!");
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    goto inputString;
                }

                Console.Write("\nWould you like to input another string? (yes/no):  ");
                userInput = Console.ReadLine().ToLower().Trim();
                redFlag = userInput != null && (userInput == "yes" || userInput == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\nHave a nice day!");
            Console.WriteLine("\n".PadLeft(36, '-'));
        }
        static int SumDigitsInString(string str)
        {
            int sum = 0;
            char[] chars = str.ToCharArray();
            foreach (var c in chars)
            {
                if (char.IsDigit(c))
                {
                    sum += Int32.Parse(c.ToString());
                }
            }
            return sum;
        }

        //      ============================== Part 3 ==============================
        static void Part3()
        {
            Console.WriteLine("Part 3:  ");
            Console.WriteLine("\n".PadLeft(15, '='));

            Console.WriteLine("Let's take an array and an integer target and find the two indecies in the array that add up to the target!\n");

            string? userInput = null;
            bool redFlag = false;
            int index1 = -1;
            int index2 = -1;
            int target = 0;
            int[] input;

            int[] inputExample = { 2, 7, 11, 15 };
            int targetExample = 9;

            TargetSumIndecies(out index1, out index2, targetExample, inputExample);
            Console.WriteLine($"The following is an example of what we are trying to do:  \n\n\tInput:  [ 2, 7, 11, 15 ] // Target:  9\n\tOutput:  [ {index1}, {index2} ]");
            Console.WriteLine("\nLet's input a target and array and attempt to achieve a similar outcome.");

            do
            {
                do
                {
                    Console.Write("Please enter a target sum:  ");
                    userInput = Console.ReadLine();
                    redFlag = Int32.TryParse(userInput, out target) ? false : true;
                    if (redFlag)
                    {
                        Console.WriteLine("Invalid Input.");
                    }
                } while (redFlag);
                do
                {
                    Console.Write("Please enter numbers seperated by a space to use as the input array:  ");
                    userInput = Console.ReadLine().Trim();
                    if (userInput != null)
                    {
                        string[] strArr = userInput.Split(" ");
                        input = new int[strArr.Length];
                        for (int i = 0; i < strArr.Length; i++)
                        {
                            redFlag = Int32.TryParse(strArr[i], out input[i]) ? false : true;
                            if (redFlag)
                            {
                                Console.WriteLine("Invalid input.");
                                break;
                            }
                        }
                        TargetSumIndecies(out index1, out index2, target, input);
                        if (index1 == -1 || index2 == -1)
                        {
                            Console.WriteLine($"\nYou have entered the following input array and target sum:  \n\tInput:  [ {string.Join(", ", input)} ] // Target:  {target}" +
                                $"\nNo two numbers in the input array are equal to the target sum {target} resulting in the following output:  [ {index1}, {index2} ]");
                        }
                        else
                        {

                            Console.WriteLine($"\nYou have entered the following input array and target sum:  \n\tInput:  [ {string.Join(", ", input)} ] // Target:  {target}" +
                                $"\nThe sum of {input[index1]} and {input[index2]} is equal to the target sum {target} at the following indecies:  [ {index1}, {index2} ]");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input.");
                        redFlag = true;
                    }
                } while (redFlag);

                Console.Write("\nWould you like to try again with different numbers? (yes/no):  ");
                userInput = Console.ReadLine().ToLower();
                redFlag = userInput != null && (userInput == "yes" || userInput == "y") ? true : false;
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!");
            Console.WriteLine("\n".PadLeft(36, '-'));
        }
        static void TargetSumIndecies(out int index1, out int index2, int target, int[] inputArray)
        {
            index1 = -1;
            index2 = -1;

            for (int i = 0; i < inputArray.Length - 1; i++)
            {
                for (int j = i + 1; j < inputArray.Length; j++)
                {
                    if (inputArray[i] + inputArray[j] == target)
                    {
                        index1 = i;
                        index2 = j;
                        break;
                    }
                }
                if (index1 != -1 || index2 != -1)
                {
                    break;
                }
            }
        }

        //      ============================== Part 4 ==============================
        static void Part4()
        {
            Console.WriteLine("Part 4:  ");
            Console.WriteLine("\n".PadLeft(15, '='));

            Console.WriteLine("Let's take a string of letters and remove all occurences of 'AB' and 'CD' and return the new smaller string!\n");

            string? userInput = null;
            bool redFlag = false;
            int minPossibleLength = -1;

            do
            {
                Console.Write("Please enter a string of letters:  ");
                userInput = Console.ReadLine().ToUpper().Trim();
                if (userInput != null)
                {
                    string strInput = userInput.Replace(" ", "");
                    strInput = strInput.Replace(",", "");
                    strInput = strInput.Replace(".", "");
                    minPossibleLength = RemoveSubs(strInput);
                    Console.WriteLine($"\nInput String:  {strInput}\nInput Length:  {strInput.Length}\nMinimum Possible Length after removing any instances of 'AB' and 'CD':  {minPossibleLength}");
                    Console.Write("\nWould you like to try again with another string? (yes/no):  ");
                    userInput = Console.ReadLine().ToLower();
                    redFlag = userInput != null && (userInput == "yes" || userInput == "y") ? true : false;
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!");
            Console.WriteLine("\n".PadLeft(36, '-'));
        }
        static int RemoveSubs(string s)
        {
            bool repeat = false;
            int len = -1;
            do
            {
                len = s.Length;
                s = s.Replace("AB", "");
                s = s.Replace("CD", "");
                repeat = len != s.Length ? true : false;
            } while (repeat);
            return len;
        }

    }
}
