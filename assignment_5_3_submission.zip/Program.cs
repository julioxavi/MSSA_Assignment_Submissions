﻿using System.Text;

namespace Assignment_5_3
{
    internal class Program
    {
        //  ************************* Main ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }

        //  ************************* Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============\n");

            Console.WriteLine("Given an integer array representing a flowerbed, let's write a program that returns true if there is an open space for 'n' new flowers and false otherwise!");

            int[] flowerBedEx = new int[] { 1, 0, 0, 0, 1 };
            int[] m1m2 = new int[] { 1, 2 };

            int[] inputArray;
            int len;
            int n = 0;

            int canPlant;
            int[] plantedFlowerBed;
            bool goodMatch;
            int count = 1;

            Random random = new Random();

            string? userInput = string.Empty;
            bool redFlag = false;
            bool greenFlag = true;

            List<int[]> flowerBeds = new List<int[]>();

            Console.WriteLine("\nFor example:  \n//////////////////////////////");
            
            foreach (var m in m1m2)
            {
                Console.WriteLine($"Checking flowerbeds for capacity to plant {m} flowers...\n===============");
                goodMatch = CanPlant(flowerBedEx, m, out plantedFlowerBed, out canPlant);
                Console.Write($"Flowerbed {count}:  ");
                for (int i = 0; i < flowerBedEx.Length; i++)
                {
                    if (i == 0)
                    {
                        Console.Write($"[ {flowerBedEx[i]}, ");
                    }
                    else if (i == flowerBedEx.Length - 1)
                    {
                        Console.Write($"{flowerBedEx[i]} ]");
                    }
                    else
                    {
                        Console.Write($"{flowerBedEx[i]}, ");
                    }
                }
                Console.Write("\nIf Planted:  ");
                for (int i = 0; i < flowerBedEx.Length; i++)
                {
                    if (i == 0)
                    {
                        if (flowerBedEx[i] == plantedFlowerBed[i])
                        {
                            Console.Write($"[ {plantedFlowerBed[i]}, ");
                        }
                        else
                        {
                            Console.Write($"[ ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write($"{plantedFlowerBed[i]}");
                            Console.ResetColor();
                            Console.Write($", ");
                        }
                    }
                    else if (i == flowerBedEx.Length - 1)
                    {
                        if (flowerBedEx[i] == plantedFlowerBed[i])
                        {
                            Console.Write($"{plantedFlowerBed[i]} ]");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write($"{plantedFlowerBed[i]}");
                            Console.ResetColor();
                            Console.Write($" ]");
                        }
                    }
                    else
                    {
                        if (flowerBedEx[i] == plantedFlowerBed[i])
                        {
                            Console.Write($"{plantedFlowerBed[i]}, ");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write($"{plantedFlowerBed[i]}");
                            Console.ResetColor();
                            Console.Write($", ");
                        }
                    }
                }
                Console.WriteLine($"\nCan Plant:  {canPlant} flower(s)");
                Console.WriteLine($"Good Match:  {goodMatch}\n---------------");
            }

            Console.WriteLine("//////////////////////////////");

            do
            {
                Console.Write("\nLet's initialize an array to serve as our flowerbed.\n---------------");
                flowerBeds.Clear();
                do
                {
                    Console.Write("\nWould you like to initialize the array manually or automatically?\n1. Manual\n2. Automatic\nEnter:  ");
                    userInput = Console.ReadLine();
                    if (userInput != null)
                    {
                        switch (userInput.ToLower().Trim())
                        {
                            case "1":
                            case "1.":
                            case "manual":
                            case "manually":
                            case "man":
                            case "m":
                                do
                                {
                                    Console.Write("\nPlease enter the amount of plots you want in your flowerbed:  ");
                                    userInput = Console.ReadLine();
                                    redFlag = int.TryParse(userInput, out len) ? false : true;
                                    if (redFlag) Console.WriteLine("Invalid input.");
                                } while (redFlag);
                                inputArray = new int[len];
                                Console.WriteLine($"\nPlease determine whether each of the {len} plots are occupied (1) or unoccupied (0):  ");
                                for (int i = 0; i < len; i++)
                                {
                                    do
                                    {
                                        Console.Write($"Plot {i + 1}:  ");
                                        userInput = Console.ReadLine();
                                        greenFlag = userInput != null && int.TryParse(userInput, out inputArray[i]) ? true : false;
                                        redFlag = greenFlag && (int.Parse(userInput) == 0 || int.Parse(userInput) == 1) ? false : true;
                                        if (redFlag) Console.WriteLine("Invalid input.  (Input must be '1' or '0' to represent an occupied or unoccupied plot respectively.)");
                                    } while (redFlag);
                                }
                                flowerBeds.Add(inputArray);
                                Console.WriteLine("\n*****Flowerbed created!*****");
                                Console.Write("\nWould you like to create another array? (yes/no):  ");
                                userInput = Console.ReadLine();
                                redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y") ? true : false;
                                break;
                            case "2":
                            case "2.":
                            case "automatic":
                            case "automatically":
                            case "auto":
                            case "a":
                                inputArray = new int[random.Next(21)];
                                for (int i = 0; i < inputArray.Length; i++)
                                {
                                    inputArray[i] = random.Next(0, 2);
                                }
                                flowerBeds.Add(inputArray);
                                Console.WriteLine("\n*****Flowerbed created!*****");
                                Console.Write("\nWould you like to create another array? (yes/no):  ");
                                userInput = Console.ReadLine();
                                redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y") ? true : false;
                                break;
                            default:
                                Console.WriteLine("Invalid input.");
                                redFlag = true;
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input.");
                        redFlag = true;
                    }
                } while (redFlag);
                Console.WriteLine("\n------------------------------");
                Console.Write("\nLet's check each flowerbed to see if we can plant a given amount of flowers!\n---------------");
                do
                {
                    Console.Write("\nPlease enter the amount of flowers you want to plant:  ");
                    userInput = Console.ReadLine();
                    greenFlag = userInput != null && int.TryParse(userInput, out n) ? true : false;
                    redFlag = greenFlag && int.Parse(userInput) > 0 ? false : true;
                    if (redFlag) Console.WriteLine("Invalid input.  Please enter a valid positive integer.");
                    else
                    {
                        Console.WriteLine($"\nChecking flowerbeds for capacity to plant {n} flowers...\n===============");
                        foreach (var flowerBed in flowerBeds)
                        {
                            goodMatch = CanPlant(flowerBed, n, out plantedFlowerBed, out canPlant);
                            Console.Write($"Flowerbed {count}:  ");
                            for (int i = 0; i < flowerBed.Length; i++)
                            {
                                if (i == 0)
                                {
                                    Console.Write($"[ {flowerBed[i]}, ");
                                }
                                else if (i == flowerBed.Length - 1)
                                {
                                    Console.Write($"{flowerBed[i]} ]");
                                }
                                else
                                {
                                    Console.Write($"{flowerBed[i]}, ");
                                }
                            }
                            Console.Write("\nIf Planted:  ");
                            for (int i = 0; i < flowerBed.Length; i++)
                            {
                                if (i == 0)
                                {
                                    if (flowerBed[i] == plantedFlowerBed[i])
                                    {
                                        Console.Write($"[ {plantedFlowerBed[i]}, ");
                                    }
                                    else
                                    {
                                        Console.Write($"[ ");
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.Write($"{plantedFlowerBed[i]}");
                                        Console.ResetColor();
                                        Console.Write($", ");
                                    }
                                }
                                else if (i == flowerBed.Length - 1)
                                {
                                    if (flowerBed[i] == plantedFlowerBed[i])
                                    {
                                        Console.Write($"{plantedFlowerBed[i]} ]");
                                    }
                                    else
                                    {
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.Write($"{plantedFlowerBed[i]}");
                                        Console.ResetColor();
                                        Console.Write($" ]");
                                    }
                                }
                                else
                                {
                                    if (flowerBed[i] == plantedFlowerBed[i])
                                    {
                                        Console.Write($"{plantedFlowerBed[i]}, ");
                                    }
                                    else
                                    {
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.Write($"{plantedFlowerBed[i]}");
                                        Console.ResetColor();
                                        Console.Write($", ");
                                    }
                                }
                            }
                            Console.WriteLine($"\nCan Plant:  {canPlant} flower(s)");
                            Console.WriteLine($"Good Match:  {goodMatch}\n---------------");
                            count++;
                        }
                        count = 1;
                        Console.Write("\nWould you like to check for a different amount of flowers? (yes/no):  ");
                        userInput = Console.ReadLine();
                        redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y") ? true : false;
                    }

                } while (redFlag);

                Console.Write("\nWould you like to check different flowerbeds? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\n\nHave a nice day!\n------------------------------\n");
        }
        static bool CanPlant(int[] flowerBed, int flowers, out int[] plantedFlowerBed, out int canPlant)
        {
            canPlant = 0;
            plantedFlowerBed = (int[])flowerBed.Clone();
            for (int i = 0; i < plantedFlowerBed.Length; i++)
            {
                if (plantedFlowerBed.Length == 1)
                {
                    if (plantedFlowerBed[i] == 0)
                    {
                        canPlant++;
                        plantedFlowerBed[i] = 1;
                    }
                }
                if (i == 0)
                {
                    if (plantedFlowerBed[i] == 0 && plantedFlowerBed[i + 1] == 0)
                    {
                        canPlant++;
                        plantedFlowerBed[i] = 1;
                    }
                }
                else if (i == plantedFlowerBed.Length - 1)
                {
                    if (plantedFlowerBed[i - 1] == 0 && plantedFlowerBed[i] == 0)
                    {
                        canPlant++;
                        plantedFlowerBed[i] = 1;
                    }
                }
                else
                {
                    if (plantedFlowerBed[i - 1] == 0 && plantedFlowerBed[i] == 0 && plantedFlowerBed[i + 1] == 0)
                    {
                        canPlant++;
                        plantedFlowerBed[i] = 1;
                    }
                }
                if (canPlant == flowers)
                {
                    return true;
                }
            }
            return false;
        }

        //  ************************* Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============\n");

            Console.WriteLine("Let's write a program that counts how many distinct ways you can climb to the top of a staircase with 'n' steps!\n");

            string? userInput = null;
            bool greenFlag = false;
            bool blueFlag = false;
            bool redFlag = true;

            int steps = 0;
            List<string> explanation;
            int count = 1;

            do
            {
                do
                {
                    Console.Write("How many steps are in your staircase?  ");
                    userInput = Console.ReadLine();
                    greenFlag = userInput != null;
                    if (greenFlag) blueFlag = int.TryParse(userInput, out steps);
                    if (blueFlag) redFlag = steps < 0;
                    if (redFlag) Console.WriteLine("Invalid input. Pleae enter a positive integer value.");
                } while (redFlag);

                explanation = GetClimbs(steps);
                Console.WriteLine($"\n***************\nInput:  There are {steps} steps in your staircase.");
                Console.WriteLine($"Output:  There are {ClimbSteps(steps)} ways to climb to the top.");
                Console.WriteLine($"\nExplanation:  ");
                foreach (var step in explanation)
                {
                    Console.WriteLine($"{count.ToString().PadLeft(2, '0')}. -> {step}");
                    count++;
                }
                count = 1;
                Console.WriteLine("\n***************\n");

                Console.Write("Would you like to climb another staircase?  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput == "yes" || userInput == "y");
            } while (redFlag);
            
            Console.WriteLine("\n\nHave a nice day!\n------------------------------\n");
        }
        static int ClimbSteps(int steps)
        {
            if (steps == 0) return 0;
            if (steps == 1) return 1;
            if (steps == 2) return 2;
            int[] uniqueClimbs = new int[steps + 1];
            string patterns = string.Empty;
            uniqueClimbs[0] = 0;
            uniqueClimbs[1] = 1;
            uniqueClimbs[2] = 2;
            for (int i = 3; i <= steps; i++)
            {
                uniqueClimbs[i] = uniqueClimbs[i - 1] + uniqueClimbs[i - 2];
            }
            foreach (var climb in uniqueClimbs)
            {

            }
            return uniqueClimbs[steps];
        }
        
        //  I had to look up how to do this part below but I understand how it works now.
        //
        //  It's hard to visualize the solutions for problems with fibonacci sequences, but
        //  after this it's definitely a bit more intuitive.

        static List<string> GetClimbs(int steps)
        {
            List<string> climbs = new List<string>();
            List<string> climbsFormated = new List<string>();
            GetSteps(steps, new List<int>(), climbs);
            foreach (var climb in climbs)
            {
                StringBuilder sb = new StringBuilder();
                foreach (char c in climb)
                {
                    if (c == '1')
                    {
                        sb.Append($"{c} step");
                    }
                    else if (c == '2')
                    {
                        sb.Append($"{c} steps");
                    }
                    else
                    {
                        sb.Append($"{c}");
                    }
                }
                climbsFormated.Add(sb.ToString());
            }
            return climbsFormated;
        }
        static void GetSteps(int steps, List<int> currentClimb, List<string> climbs)
        {
            if (steps == 0)
            {
                climbs.Add(string.Join(" + ", currentClimb));
                return;
            }
            if (steps < 0)
            {
                return;
            }

            currentClimb.Add(1);
            GetSteps(steps - 1, currentClimb, climbs);
            currentClimb.RemoveAt(currentClimb.Count - 1);

            currentClimb.Add(2);
            GetSteps(steps - 2, currentClimb, climbs);
            currentClimb.RemoveAt(currentClimb.Count - 1);
        }
    }
}
