﻿namespace Assignment_5_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Part1();
            Part2();
            Part3();
            Part4();
        }

        //  ******************** Part 1 ********************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n============\n");

            Console.WriteLine("Let's create a method that returns the length of the last word in a given string.");

            string? userInput = null;
            bool redFlag = false;

            List<string> results = new List<string>();
            results.Add($"Input:  s = \"Hello World\"\nOutput:  {FinalWordLength(FinalWord("Hello World"))}\nExplanation:  The last word \"{FinalWord("Hello World")}\" has a length of {FinalWordLength(FinalWord("Hello World"))}");
            results.Add($"Input:  s = \" fly me to the moon \"\nOutput:  {FinalWordLength(FinalWord(" fly me to the moon ".TrimEnd()))}\nExplanation:  The last word \"{FinalWord(" fly me to the moon ".TrimEnd())}\" has a length of {FinalWordLength(FinalWord(" fly me to the moon ".TrimEnd()))}");

            do
            {
                do
                {
                    Console.Write("\nPlease enter a string:  ");
                    userInput = Console.ReadLine().TrimEnd();
                    redFlag = userInput != null ? false : true;
                    if (redFlag) Console.WriteLine("Invalid input.");
                } while (redFlag);

                results.Add($"Input:  s = \"{userInput}\"\nOutput:  {FinalWordLength(FinalWord(userInput))}\nExplanation:  The last word \"{FinalWord(userInput)}\" has a length of {FinalWordLength(FinalWord(userInput))}");

                Console.Write("\nWould you like to enter another string before viewing the results? (yes/no):  ");
                userInput = Console.ReadLine().ToLower();
                redFlag = userInput != null && (userInput == "yes" || userInput == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\nResults:  \n<><><><><><><><><><><><>");
            foreach (var result in results)
            {
                Console.WriteLine(result);
                Console.WriteLine("------------");
            }

            Console.WriteLine("\nHave a nice day!\n------------------------\n");
        }
        static int FinalWordLength(string w)
        {
            return w.Length;
        }
        static string FinalWord(string s)
        {
            int i = -1;
            string w = string.Empty;
            for (int j = s.Length - 1; j >= 0; j--)
            {
                if (s[j - 1] == ' ')
                {
                    w = s.Substring(j);
                    break;
                }
            }
            return w;
        }

        //  ******************** Part 2 ********************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n============\n");

            Console.WriteLine("Let's write a program that prints the first 'n' natural numbers using recursion!");

            Console.WriteLine("\nFor example:  \n------------");
            Console.WriteLine($"How many numbers to print:  {10}");
            Console.Write("Output:  ");
            PrintNumbers(10);
            Console.WriteLine();

            int n = 0;

            string? userInput = null;
            bool redFlag = false;
            bool greenFlag = true;

            do
            {
                do
                {
                    Console.Write("\nPlease enter how many numbers you want to print:  ");
                    userInput = Console.ReadLine();
                    greenFlag = int.TryParse(userInput, out n) ? true : false;
                    redFlag = greenFlag && int.Parse(userInput) > 0 ? false : true;
                    if (redFlag) Console.WriteLine("Please enter a valid positive integer.");
                } while (redFlag);

                Console.WriteLine($"\nHow many numbers to print:  {n}");
                Console.Write("Output:  ");
                PrintNumbers(n);
                Console.WriteLine();

                Console.Write("\nWould you like to print a different amount of numbers? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower() == "yes" || userInput.ToLower() == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------\n");
        }
        static void PrintNumbers(int n)
        {
            if (n > 1) PrintNumbers(n - 1);
            Console.Write($"{n} ");
        }

        //  ******************** Part 3 ********************
        static void Part3()
        {
            Console.WriteLine("Part 3:  \n============\n");

            Console.WriteLine("Let's write a program that prints numbers 'n' to 1 using recursion!");

            Console.WriteLine("\nFor example:  \n------------");
            Console.WriteLine($"How many numbers to print:  {10}");
            Console.Write("Output:  ");
            PrintNumbersInverse(10);
            Console.WriteLine();

            int n = 0;

            string? userInput = null;
            bool redFlag = false;
            bool greenFlag = true;

            do
            {
                do
                {
                    Console.Write("\nPlease enter how many numbers you want to print:  ");
                    userInput = Console.ReadLine();
                    greenFlag = int.TryParse(userInput, out n) ? true : false;
                    redFlag = greenFlag && int.Parse(userInput) > 0 ? false : true;
                    if (redFlag) Console.WriteLine("Please enter a valid positive integer.");
                } while (redFlag);

                Console.WriteLine($"\nHow many numbers to print:  {n}");
                Console.Write("Output:  ");
                PrintNumbersInverse(n);
                Console.WriteLine();

                Console.Write("\nWould you like to print a different amount of numbers? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower() == "yes" || userInput.ToLower() == "y") ? true : false;

            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------\n");
        }
        static void PrintNumbersInverse(int n)
        { 
            Console.Write($"{n} ");
            if (n > 1) PrintNumbersInverse(n - 1);
        }

        //  ******************** Part 4 ********************
        static void Part4()
        {
            Console.WriteLine("Part 4:  \n============\n");

            Console.WriteLine("Let's check whether a given string is a Palindrome or not using recursion!");
            Console.WriteLine("\nFor example:  \n---------------");
            Console.WriteLine($"\nInput:  \"RADAR\"");
            IsPalindrome("RADAR");

            string? userInput = null;
            bool redFlag = false;

            do
            {
                do
                {
                    Console.Write("\nPlease enter a string:  ");
                    userInput = Console.ReadLine();
                    redFlag = userInput != null ? false : true;
                    if (redFlag) Console.WriteLine("Invalid input.");
                } while (redFlag);

                Console.WriteLine($"\nInput:  \"{userInput}\"");
                IsPalindrome(userInput.ToString());

                Console.Write("\nDo you want to enter another string? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower() == "yes" || userInput.ToLower() == "y") ? true : false;
                
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------\n");
        }
        static void IsPalindrome(string s)
        {
            if (s.Length <= 1)
            {
                Console.WriteLine("Output:  The string IS palindrome.");
            }
            else if (s[0] == s[s.Length - 1] && s.Length > 1)
            {
                s = s.Remove(s.Length - 1, 1);
                s = s.Remove(0, 1);
                IsPalindrome(s);
            }
            else
            {
                Console.WriteLine("Output:  The string IS NOT palindrome.");
            }
            
        }
    }
}
