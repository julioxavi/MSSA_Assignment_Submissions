﻿namespace Assignment_13_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Part 1:  \n______________________________\n");
            
            Console.WriteLine("Given two non-empty linked lists that represent two positive integers whose digits are stored in reverse, let's add those two numbers and return the sum as a linked list!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random linked lists and return sum? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.WriteLine("\n------------------------------------------------------------");
                            Node num1 = GenerateRandomSLLHead();
                            Node num2 = GenerateRandomSLLHead();
                            Console.Write("Num 1:  ");
                            DisplaySLL(num1);
                            Console.Write("Num 2:  ");
                            DisplaySLL(num2);
                            Console.WriteLine("==============================");
                            Node num3 = SumTwoSLLs(num1, num2);
                            Console.Write("Num 3:  ");
                            DisplaySLL(num3);
                            Console.Write("Explanation:  ");
                            DisplayExplanation(num1, num2, num3);
                            Console.WriteLine("------------------------------------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static void DisplayExplanation(Node head1, Node head2, Node head3)
        {
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;
            int spot1 = 1;
            int spot2 = 1;
            int spot3 = 1;
            while (head1 != null)
            {
                num1 += head1.Value * spot1;
                spot1 *= 10;
                head1 = head1.Next;
            }
            while (head2 != null)
            {
                num2 += head2.Value * spot2;
                spot2 *= 10;
                head2 = head2.Next;
            }
            while (head3 != null)
            {
                num3 += head3.Value * spot3;
                spot3 *= 10;
                head3 = head3.Next;
            }
            Console.WriteLine($"The sum of '{num1}' and '{num2}' is equal to '{num3}'");
        }
        static Node SumTwoSLLs(Node head1, Node head2)
        {
            Node temp1 = head1;
            Node temp2 = head2;
            int sum = 0;
            int spot = 1;
            while (temp1 != null || temp2 != null)
            {
                if (temp1 == null)
                {
                    sum += temp2.Value * spot;
                    temp2 = temp2.Next;
                    spot *= 10;
                }
                else if (temp2 == null)
                {
                    sum += temp1.Value * spot;
                    temp1 = temp1.Next;
                    spot *= 10;
                }
                else
                {
                    sum += (temp1.Value * spot) + (temp2.Value * spot);
                    temp1 = temp1.Next;
                    temp2 = temp2.Next;
                    spot *= 10;
                }
            }
            string sumStr = sum.ToString();
            Node head = null;
            for (int i = 0; i < sumStr.Length; i++)
            {
                if (i == 0)
                {
                    Node newNode = new Node(sumStr[i] - '0');
                    head = newNode;
                }
                else
                {
                    Node newNode = new Node(sumStr[i] - '0');
                    newNode.Next = head;
                    head = newNode;
                }
            }
            return head;
        }
        static Node GenerateRandomSLLHead()
        {
            Random r = new Random();
            Node head = null;
            Node prev = head;
            int len = r.Next(1, 10);
            for (int i = 0; i <= len; i++)
            {
                Node newNode = new Node(r.Next(10));
                if (i == 0)
                {
                    if (newNode.Value == 0)
                        newNode.Value = r.Next(1, 10);
                    head = newNode;
                    prev = head;
                }
                else
                {
                    prev.Next = newNode;
                    prev = newNode;
                }
            }
            return head;
        }
        static void DisplaySLL(Node head)
        {
            Node temp = head;
            while (temp != null)
            {
                if (temp.Next == null)
                {
                    Console.WriteLine($"({temp.Value})");
                }
                else
                {
                    Console.Write($"({temp.Value}) -> ");
                }
                temp = temp.Next;
            }
        }
    }
    public class Node
    {
        public int Value { get; set; }
        public Node Next;
        public Node(int val)
        {
            Value = val;
            Next = null;
        }
    }
}
