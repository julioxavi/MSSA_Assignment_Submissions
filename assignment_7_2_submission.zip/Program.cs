﻿namespace Assignment_7_2
{
    enum Vowel
    {
        A,
        E,
        I,
        O,
        U
    }
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
            Part3();
        }

        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============\n");

            Console.WriteLine("Let's implement a merge sort on an unsorted array of numbers taken from the user!");

            string? userInput = null;
            bool redFlag = true;
            bool greenFlag = false;

            int[] input = null;

            do
            {
                Console.Write("\nSort array? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.Write("Input array or initialize random array? (1,2,0):  \n1. Input array\n2. Random array\n0. Exit\nEnter:  ");
                            userInput = Console.ReadLine();
                            if (userInput == null)
                            {
                                Console.WriteLine("Invalid input");
                                redFlag = true;
                            }
                            else
                            {
                                switch (userInput.ToLower())
                                {
                                    case "1":
                                    case "input":
                                    case "input array":
                                        InputArray(out input);
                                        redFlag = true;
                                        greenFlag = true;
                                        break;
                                    case "2":
                                    case "random":
                                    case "random array":
                                        InitializeRandomArray(out input);
                                        redFlag = true;
                                        greenFlag = true;
                                        break;
                                    case "0":
                                    case "exit":
                                        redFlag = false;
                                        greenFlag = false;
                                        break;
                                    default:
                                        Console.WriteLine("Invalid input.");
                                        redFlag = true;
                                        greenFlag = false;
                                        break;
                                }
                                if (greenFlag)
                                {
                                    Console.WriteLine($"\n==============================");
                                    Console.WriteLine($"Input (unsorted):   [ {string.Join(", ", input)} ]");
                                    MergeSort(input);
                                    Console.WriteLine($"Output (sorted):    [ {string.Join(", ", input)} ]");
                                    Console.WriteLine($"==============================");
                                }
                            }
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void MergeSort(int[] input)
        {
            int left = 0;
            int right = input.Length - 1;
            Divide(input, left, right);
        }
        static void Divide(int[]input, int left, int right)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;
                Divide(input, left, mid);
                Divide(input, mid + 1, right);
                Conquer(input, left, mid, right);
            }
        }
        static void Conquer(int[] input, int left, int mid, int right)
        {
            int i = left;
            int j = mid + 1;
            int[] temp = new int[right + 1];
            int k = left;

            while (i <= mid && j <= right)
            {
                if (input[i] <= input[j])
                {
                    temp[k] = input[i];
                    i++;
                }
                else
                {
                    temp[k] = input[j];
                    j++;
                }
                k++;
            }
            while (i <= mid)
            {
                temp[k] = input[i];
                i++;
                k++;
            }
            while (j <= right)
            {
                temp[k] = input[j];
                j++;
                k++;
            }
            for (int x = left; x <= right; x++)
            {
                input[x] = temp[x];
            }
        }
        static void InitializeRandomArray(out int[] input)
        {
            Random roll = new Random();
            int len = roll.Next(10);
            input = new int[len];
            for (int i = 0; i < len; i++)
            {
                input[i] = roll.Next(21);
            }
        }
        static void InputArray(out int[] input)
        {
            string? userInput = null;
            bool redFlag = true;
            bool greenFlag = false;
            bool blueFlag = false;
            input = null;

            do
            {
                Console.Write("\nArray length:  ");
                userInput = Console.ReadLine();
                redFlag = userInput == null;
                if (redFlag)
                {
                    Console.WriteLine("Invalid input.");
                }
                else
                {
                    blueFlag = int.TryParse(userInput, out int len);
                    if (blueFlag)
                    {
                        greenFlag = len < 21 && len > 0;
                        if (greenFlag)
                        {
                            input = new int[len];
                            for (int i = 0; i < len; i++)
                            {
                                do
                                {
                                    Console.Write($"Element at Index {i}:  ");
                                    userInput = Console.ReadLine();
                                    redFlag = userInput == null;
                                    if (redFlag)
                                    {
                                        Console.WriteLine("Invalid input.");
                                    }
                                    else
                                    {
                                        greenFlag = int.TryParse(userInput, out input[i]);
                                        if (!greenFlag)
                                        {
                                            Console.WriteLine("Invalid input.");
                                            redFlag = true;
                                        }
                                    }
                                } while (redFlag);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Please input a length that is a positive integer less than or equal to 20.");
                            redFlag = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input.");
                        redFlag = true;
                    }
                }
            } while (redFlag);
            
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============\n");

            Console.WriteLine("Let's a string, reverse only all the vowels in it, and return it!");

            string s_ex1 = "hello";
            string s_ex2 = "avacado";
            string s_ex3 = "intelligent";
            Console.WriteLine($"Input: \"{s_ex1}\"");
            ReverseVowels(ref s_ex1);
            Console.WriteLine($"Output: \"{s_ex1}\"");
            Console.WriteLine($"\nInput: \"{s_ex2}\"");
            ReverseVowels(ref s_ex2);
            Console.WriteLine($"Output: \"{s_ex2}\"");
            Console.WriteLine($"\nInput: \"{s_ex3}\"");
            ReverseVowels(ref s_ex3);
            Console.WriteLine($"Output: \"{s_ex3}\"");

            string? userInput = null;
            bool redFlag = true;
            List<string> words = new List<string>();

            Console.WriteLine("\n***** (results will show after all desired strings have been inputed) *****");

            do
            {
                Console.Write("\nReverse word? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            do
                            {
                                Console.Write("\nInput word:  ");
                                userInput = Console.ReadLine();
                                if (userInput == null)
                                {
                                    Console.WriteLine("Invalid input.");
                                    redFlag = true;
                                }
                                else
                                {
                                    words.Add(userInput);
                                    redFlag = false;
                                }
                            } while (redFlag);
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\n==============================");
            foreach (var word in words)
            {
                string temp = word;
                Console.WriteLine($"Input: \"{temp}\"");
                ReverseVowels(ref temp);
                Console.WriteLine($"Output: \"{temp}\"");
            }
            Console.WriteLine("==============================");

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void ReverseVowels(ref string s)
        {
            char[] c = s.ToCharArray();
            int i = 0;
            int j = s.Length - 1;
            while (i < j)
            {
                while (!Vowel.TryParse(c[i].ToString(), true, out Vowel lvowel))
                {
                    i++;
                    if (i >= j)
                    {
                        break;
                    }
                }
                while (!Vowel.TryParse(c[j].ToString(), true, out Vowel rvowel))
                {
                    j--;
                    if (i >= j)
                    {
                        break;
                    }
                }
                if (i < j)
                {
                    char temp = c[i];
                    c[i] = c[j];
                    c[j] = temp;
                    i++;
                    j--;
                }
                else
                {
                    break;
                }
            }
            s = string.Concat(c);
        }

        //  ****************************** Part 3 ******************************
        static void Part3()
        {
            Console.WriteLine("Part 3:  \n===============\n");

            string ex1_s = "anagram";
            string ex1_t = "nagaram";
            string ex2_s = "rat";
            string ex2_t = "car";
            Console.WriteLine($"IsAnagram(\"{ex1_s}\", \"{ex1_t}\"):  {IsAnagram(ex1_s, ex1_t)}");
            Console.WriteLine($"IsAnagram(\"{ex2_s}\", \"{ex2_t}\"):  {IsAnagram(ex2_s, ex2_t)}");

            string s = string.Empty;
            string t = string.Empty;
            string? userInput = null;
            bool redFlag = true;
            bool orangeFlag = true;
            List<(string, string)> strings = new List<(string, string)>();

            Console.WriteLine("\n***** (results will show after all desired pairs of strings have been inputed) *****");

            do
            {
                Console.Write("\nInput two strings to check if they are anagrams? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
                else
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            do
                            {
                                Console.Write("Input string 's':  ");
                                userInput = Console.ReadLine();
                                if (userInput == null)
                                {
                                    Console.WriteLine("Invalid input");
                                    orangeFlag = true;
                                }
                                else
                                {
                                    s = userInput;
                                    orangeFlag = false;
                                }
                            } while (orangeFlag);
                            do
                            {
                                Console.Write("Input string 't':  ");
                                userInput = Console.ReadLine();
                                if (userInput == null)
                                {
                                    Console.WriteLine("Invalid input");
                                    orangeFlag = true;
                                }
                                else
                                {
                                    t = userInput;
                                    orangeFlag = false;
                                }
                            } while (orangeFlag);
                            strings.Add((s, t));
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\n==============================");
            foreach (var pair in strings)
            {
                Console.WriteLine($"IsAnagram(\"{pair.Item1}\", \"{pair.Item2}\"):  {IsAnagram(pair.Item1, pair.Item2)}");
            }
            Console.WriteLine("==============================");

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static bool IsAnagram(string s, string t)
        {
            if (s.ToLower().ToCharArray().Length != t.ToLower().ToCharArray().Length)
            {
                return false;
            }
            Dictionary<char, int> sd = new Dictionary<char, int>();
            Dictionary<char, int> td = new Dictionary<char, int>();
            foreach (char c in s)
            {
                if (c == ' ' || c == '-' || c == ',' || c == '.')
                {
                    continue;
                }
                if (sd.ContainsKey(c))
                {
                    sd[c] += 1;
                }
                else
                {
                    sd[c] = 1;
                }
            }
            foreach (char c in t)
            {
                if (c == ' ' || c == '-' || c == ',' || c == '.')
                {
                    continue;
                }
                if (td.ContainsKey(c))
                {
                    td[c] += 1;
                }
                else
                {
                    td[c] = 1;
                }
            }
            if (sd.Count == td.Count)
            {
                foreach (KeyValuePair<char, int> kvp in sd)
                {
                    if (td.TryGetValue(kvp.Key, out int val) && val == kvp.Value)
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
            return true;
        }
    }
}
