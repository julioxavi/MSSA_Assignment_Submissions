﻿using System.Collections.Concurrent;
using static System.Net.Mime.MediaTypeNames;

namespace Week11ChallengeLabs
{
    internal class Program
    {
        //  ******************************  Main  ******************************
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }
        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n______________________________");

            Console.WriteLine("Given a number array with 'n' objects colored red (0), white (1), and blue (2); let's sort them in place so that objects of the same color can be adjacent and in order!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Genereate random color array and sort by color? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            var colors = GenerateRandomColorArray();
                            Console.WriteLine("\n------------------------------");
                            Console.Write("Color array before sorting:\t");
                            DisplayColorArray(colors);
                            SortColorArray(colors);
                            Console.Write("Color array after sorting:\t");
                            DisplayColorArray(colors);
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static int[] GenerateRandomColorArray()
        {
            Random r = new Random();
            int[] colors = new int[r.Next(0, 15)];
            for (int i = 0; i < colors.Length; i++)
            {
                colors[i] = r.Next(0, 3);
            }
            return colors;
        }
        static void SortColorArray(int[] colors)
        {
            quicksort(colors, 0, colors.Length - 1);
        }
        private static void quicksort(int[] arr, int low, int high)
        {
            if (low < high)
            {
                int p_index = partition(arr, low, high);
                quicksort(arr, low, p_index - 1);
                quicksort(arr, p_index + 1, high);
            }
        }
        private static int partition(int[] arr, int low, int high)
        {
            int pivot = arr[low];
            int i = low;
            int j = high;
            do
            {
                while (i <= j && arr[i] <= pivot)
                {
                    i++;
                }
                while (i <= j && arr[j] >= pivot)
                {
                    j--;
                }
                if (i <= j)
                {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            } while (i < j);
            if (low != j)
            {
                int temp = arr[low];
                arr[low] = arr[j];
                arr[j] = temp;
            }
            return j;
        }
        static void DisplayColorArray(int[] colors)
        {
            Console.Write("[ ");
            for (int i = 0; i < colors.Length; i++)
            {
                if (i == 0)
                {
                    if (colors[i] == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write($"{colors[i]}");
                        Console.ResetColor();
                    }
                    else if (colors[i] == 1)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write($"{colors[i]}");
                        Console.ResetColor();
                    }
                    else if (colors[i] == 2)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write($"{colors[i]}");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write($"{colors[i]}");
                        Console.ResetColor();
                    }
                }
                else
                {
                    if (colors[i] == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write($", {colors[i]}");
                        Console.ResetColor();
                    }
                    else if (colors[i] == 1)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write($", {colors[i]}");
                        Console.ResetColor();
                    }
                    else if (colors[i] == 2)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write($", {colors[i]}");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write($", {colors[i]}");
                        Console.ResetColor();
                    }
                }
            }
            Console.WriteLine(" ]");
        }
        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n______________________________");

            Console.WriteLine("Given a string text, let's use the characters to form as many instances of the word \"balloon\" as possible return that number!\n");

            string text1 = "nlaebolko";
            string text2 = "loonbalxballpoon";
            string text3 = "leetcode";
            string text4 = "rrbolbojllaoaunooobatniabiobnllojalg";
            string text5 = "gallblbnololdndfgohobtlolbnnavonulpmobveblhlkostnabnqalaooal";
            string text6 = "abgpobblltlnnnlaomolpyoyonxomanyklmtlaqomlaboold";
            int maxBalloons;

            maxBalloons = BalloonCount(text1);
            DisplayBalloonCount(text1, maxBalloons);

            maxBalloons = BalloonCount(text2);
            DisplayBalloonCount(text2, maxBalloons);

            maxBalloons = BalloonCount(text3);
            DisplayBalloonCount(text3, maxBalloons);

            maxBalloons = BalloonCount(text4);
            DisplayBalloonCount(text4, maxBalloons);

            maxBalloons = BalloonCount(text5);
            DisplayBalloonCount(text5, maxBalloons);

            maxBalloons = BalloonCount(text6);
            DisplayBalloonCount(text6, maxBalloons);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static int BalloonCount(string text)
        {
            Dictionary<char, int> balloonCount = new Dictionary<char, int>() { { 'b', 0 }, { 'a', 0 }, { 'l', 0 }, { 'o', 0 }, { 'n', 0 } };
            int count = 1;
            int balloons = 0;
            foreach (char c in text)
            {
                if (balloonCount.ContainsKey(c))
                {
                    balloonCount[c]++;
                }
            }
            while (balloonCount.ContainsValue(count) || count <= balloonCount.Values.Min())
            {
                if (balloonCount['l'] >= count * 2 && balloonCount['o'] >= count * 2)
                {
                    balloons++;
                }
                count++;
            }
            return balloons;
        }
        static void DisplayBalloonCount(string text, int balloons)
        {
            int b = balloons;
            int a = balloons;
            int l = balloons * 2;
            int o = balloons * 2;
            int n = balloons;
            Dictionary<int, ConsoleColor> colors = new Dictionary<int, ConsoleColor>() { { 1, ConsoleColor.Red }, { 2, ConsoleColor.Green }, { 3, ConsoleColor.Blue }, { 4, ConsoleColor.Yellow }, { 5, ConsoleColor.Magenta } };
            Console.WriteLine("\n------------------------------");
            Console.Write("Text:  \" ");
            if (balloons > 0)
            {
                foreach (char c in text)
                {
                    if (c == 'b')
                    {
                        if (colors.ContainsKey(b))
                        {
                            Console.ForegroundColor = colors[b];
                            Console.Write($"{c.ToString().ToUpper()} ");
                            Console.ResetColor();
                            b--;
                        }
                        else
                        {
                            Console.Write($"{c.ToString().ToUpper()} ");
                        }
                    }
                    else if (c == 'a')
                    {
                        if (colors.ContainsKey(a))
                        {
                            Console.ForegroundColor = colors[a];
                            Console.Write($"{c.ToString().ToUpper()} ");
                            Console.ResetColor();
                            a--;
                        }
                        else
                        {
                            Console.Write($"{c.ToString().ToUpper()} ");
                        }
                    }
                    else if (c == 'l')
                    {
                        if (colors.ContainsKey((l / 2) + (l % 2)))
                        {
                            Console.ForegroundColor = colors[(l / 2) + (l % 2)];
                            Console.Write($"{c.ToString().ToUpper()} ");
                            Console.ResetColor();
                            l--;
                        }
                        else
                        {
                            Console.Write($"{c.ToString().ToUpper()} ");
                        }
                    }
                    else if (c == 'o')
                    {
                        if (colors.ContainsKey((o / 2) + (o % 2)))
                        {
                            Console.ForegroundColor = colors[(o / 2) + (o % 2)];
                            Console.Write($"{c.ToString().ToUpper()} ");
                            Console.ResetColor();
                            o--;
                        }
                        else
                        {
                            Console.Write($"{c.ToString().ToUpper()} ");
                        }
                    }
                    else if (c == 'n')
                    {
                        if (colors.ContainsKey(n))
                        {
                            Console.ForegroundColor = colors[n];
                            Console.Write($"{c.ToString().ToUpper()} ");
                            Console.ResetColor();
                            n--;
                        }
                        else
                        {
                            Console.Write($"{c.ToString().ToUpper()} ");
                        }
                    }
                    else
                    {
                        Console.Write($"{c.ToString().ToUpper()} ");
                    }
                }
            }
            else
            {
                Console.Write($"{string.Join(" ", text.ToUpper().ToCharArray())} ");
            }
            Console.WriteLine("\"");
            Console.WriteLine($"\nBalloon instances:  {balloons}");
            Console.WriteLine("------------------------------\n");
        }
    }
}
