﻿using System.Text;

namespace Week10ChallengeLabs
{
    internal class Program
    {
        //  ****************************** _Main_ ******************************
        static void Main(string[] args)
        {
            //Part1();
            Part2();
        }

        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n______________________________\n");

            Console.WriteLine("Let's take two strings and find the extra character in the second string!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write($"Generate strings and find extra character? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            string s = GenerateRandomString();
                            string t = ShuffleStringPlusOne(s);
                            char x = FindExtraChar(s, t);
                            Console.WriteLine("\n------------------------------");
                            Console.WriteLine($"Original string (s):  \"{s}\"");
                            Console.WriteLine($"Shuffled string (t):  \"{t}\"");
                            Console.WriteLine($"Extra character (x):  '{x}'");
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.)");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static string GenerateRandomString()
        {
            Random r = new Random();
            StringBuilder sb = new StringBuilder();
            int length = r.Next(0, 10);
            for (int i = 0; i < length; i++)
            {
                sb.Append((char)r.Next('a', 'z' + 1));
            }
            return sb.ToString();
        }
        static string ShuffleStringPlusOne(string s)
        {
            Random r = new Random();
            StringBuilder sb = new StringBuilder();
            sb.Append(s);
            sb.Append((char)r.Next('a', 'z' + 1));
            char[] chars = sb.ToString().ToCharArray();
            for (int i = chars.Length - 1; i > 0; i--)
            {
                int randomIndex = r.Next(0, i + 1);
                char temp = chars[i];
                chars[i] = chars[randomIndex];
                chars[randomIndex] = temp;
            }
            return new string(chars);
        }
        static char FindExtraChar(string s, string t)
        {
            foreach (char c in t)
            {
                if (!s.Contains(c))
                {
                    return c;
                }
                else
                {
                    s = s.Remove(s.IndexOf(c), 1);
                }
            }
            return '\0'; // Return null character if no extra char is found
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n______________________________\n");

            Console.WriteLine("Let's take two sorted interger arrays and merge them into one sorted array in place!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate and merge two random sorted arrays? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            (int[] nums1, int[] nums2) = GenerateRandomArrays();
                            Console.WriteLine("\n------------------------------");
                            Console.WriteLine($"Input arrays:\tnums1 = [ {string.Join(", ", nums1)} ]\n\t\tnums2 = [ {string.Join(", ", nums2)} ]");
                            Console.WriteLine($"\n*****\n\t\tmerging -> [ {string.Join(", ", nums1[..(nums1.Length - nums2.Length)])} ]\n\t\t + with -> [ {string.Join(", ", nums2)} ]\n*****\n");
                            MergeArrays(nums1, nums2);
                            Console.WriteLine($"Output array:\tnums1 = [ {string.Join(", ", nums1)} ]");
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static (int[], int[]) GenerateRandomArrays()
        {
            Random r = new Random();
            int[] nums0 = new int[r.Next(0, 10)];
            int[] nums2 = new int[r.Next(0, 10)];
            int[] nums1 = new int[nums0.Length + nums2.Length];
            for (int i = 0; i < nums0.Length; i++)
            {
                nums0[i] = r.Next(0, 21);
            }
            for (int i = 0; i < nums2.Length; i++)
            {
                nums2[i] = r.Next(0, 21);
            }
            nums0.Sort();
            nums2.Sort();
            Array.Copy(nums0, nums1, nums0.Length);
            return (nums1, nums2);
        }
        static void MergeArrays(int[] nums1, int[] nums2)
        {
            int m_plus_n = nums1.Length;
            int n = nums2.Length;
            int m = m_plus_n - n;

            int p0 = m - 1; // Pointer for nums in nums1
            int p1 = m_plus_n - 1; // Pointer for nums1
            int p2 = n - 1; // Pointer for nums2
            
            while (p2 >= 0)
            {
                if(p0 < 0)
                {
                    Array.Copy(nums2, nums1, p2 + 1);
                    break;
                }
                else if (nums2[p2] > nums1[p0])
                {
                    nums1[p1] = nums2[p2];
                    p2--;
                    p1--;
                }
                else
                {
                    nums1[p1] = nums1[p0];
                    p0--;
                    p1--;
                }
            }

        }
    }
}
