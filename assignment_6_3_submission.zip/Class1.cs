﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_6_3
{
    internal class Customer
    {
        public int TicketNumber { get; set; }
        public Customer Next;
        public Customer(int val)
        {
            TicketNumber = val;
            Next = null;
        }
    }
    class CustomerQ
    {
        Customer front, rear;
        int size;
        public CustomerQ()
        {
            front = rear = null;
            size = 0;
        }
        public bool IsEmpty()
        {
            return size == 0;
        }
        public void Enqueue(int val)
        {
            Customer newCust = new Customer(val);
            if (IsEmpty())
            {
                front = newCust;
            }
            else
            {
                rear.Next = newCust;
            }
            rear = newCust;
            size++;
        }
        public int Dequeue()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Queue is empty...");
            }
            int val = front.TicketNumber;
            front = front.Next;
            size--;
            if (IsEmpty())
            {
                front = null;
                rear = null;
            }
            return val;
        }
        public void Display()
        {
            Customer temp = front;
            if (IsEmpty())
            {
                Console.WriteLine("Queue is empty...");
                return;
            }
            Console.Write("[ ");
            while (temp != null)
            {
                Console.Write(temp.TicketNumber + " ");
                temp = temp.Next;
            }
            Console.WriteLine("]");
        }
    }
}
