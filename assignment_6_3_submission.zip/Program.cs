﻿namespace Assignment_6_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***************\nAUTOMOTIVE REPAIR SHOP:  Repairs Made Easy\n***************\n");

            CustomerQ tickets = new CustomerQ();
            tickets.Display();

            tickets.Enqueue(1001);
            tickets.Enqueue(1005);
            tickets.Enqueue(807);
            Console.Write("Tickets awaiting to be serviced:  ");
            tickets.Display();
            Console.WriteLine($"\nNow Servicing ticket#:  [ {tickets.Dequeue()} ]");
            Console.Write("Tickets awaiting to be serviced:  ");
            tickets.Display();
        }
    }
}
