﻿using System;
using System.Collections.Generic;
using System.Net.Security;
using System.Runtime.InteropServices;
using System.Text;

namespace Assignment_7_4
{
    enum Size
    {
        None,
        Small,
        Medium,
        Big
    }
    class Car
    {
        public Size carType;
        public Car(Size size)
        {
            carType = size;
        }
    }
    internal class ParkingSystem
    {
        ParkingLot bigLot;
        ParkingLot mediumLot;
        ParkingLot smallLot;
        public ParkingSystem(int big, int medium, int small)
        {
            bigLot = new ParkingLot(big);
            mediumLot = new ParkingLot(medium);
            smallLot = new ParkingLot(small);
        }
        public bool addCar(Car car)
        {
            switch (car.carType)
            {
                case Size.Big:
                    return bigLot.Park();
                case Size.Medium:
                    return mediumLot.Park();
                case Size.Small:
                    return smallLot.Park();
                default:
                    Console.WriteLine("Invalid car type.");
                    return false;
            }
        }
        public bool removeCar(Car car)
        {
            switch (car.carType)
            {
                case Size.Big:
                    return bigLot.Leave();
                case Size.Medium:
                    return mediumLot.Leave();
                case Size.Small:
                    return smallLot.Leave();
                default:
                    Console.WriteLine("Invalid car type.");
                    return false;
            }
        }
        public void DisplayAll()
        {
            bigLot.Display();
            mediumLot.Display();
            smallLot.Display();
        }
    }
    class ParkingLot
    {
        bool[] spots;
        int front;
        int rear;
        int size;
        public ParkingLot(int capacity)
        {
            spots = new bool[capacity];
            front = -1;
            rear = -1;
            size = 0;
        }
        public bool IsEmpty()
        {
            return size == 0;
        }
        public bool IsFull()
        {
            return rear == spots.Length - 1;
        }
        public bool Park()
        {
            if (IsFull())
            {
                Console.WriteLine("Lot is full...");
                return false;
            }
            rear++;
            spots[rear] = true;
            size++;
            return true;
        }
        public bool Leave()
        {
            if (IsEmpty())
            {
                Console.WriteLine("Lot is empty...");
                return false;
            }
            front++;
            spots[front] = false;
            size--;
            if (IsEmpty())
            {
                front = -1;
                rear = -1;
            }
            return true;
        }
        public void Display()
        {
            Console.WriteLine($"\nLot capacity: {spots.Length}\nSpots Occupied:  ");
            int counter = 1;
            int filled = 0;
            foreach (var spot in spots)
            {
                Console.WriteLine($"Spot {counter}:  {spots[counter - 1]}");
                counter++;
                if (spot == true) { filled++; }
            }
            Console.WriteLine($"Spots filled:  {filled}/{spots.Length}");
        }
    }
}
