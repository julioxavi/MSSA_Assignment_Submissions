﻿namespace Assignment_7_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car volkswagon = new Car(Size.Small);
            Car honda = new Car(Size.Small);
            Car subaru = new Car(Size.Small);
            Car mitsubishi = new Car(Size.Medium);
            Car ford = new Car(Size.Big);
            Car toyota = new Car(Size.Medium);
            Car porche = new Car(Size.Small);
            Car chevy = new Car(Size.Big);
            Car mazda = new Car(Size.Small);

            ParkingSystem parkingLot = new ParkingSystem(1, 2, 3);

            Console.WriteLine($"\nPark volkswagon:  {parkingLot.addCar(volkswagon)}");
            Console.WriteLine($"Park honda:  {parkingLot.addCar(honda)}");
            Console.WriteLine($"Park subaru:  {parkingLot.addCar(subaru)}");
            Console.WriteLine($"Park mitsubishi:  {parkingLot.addCar(mitsubishi)}");
            Console.WriteLine($"Park ford:  {parkingLot.addCar(ford)}");
            Console.WriteLine($"Park toyota:  {parkingLot.addCar(toyota)}");
            Console.WriteLine($"Park porche:  {parkingLot.addCar(porche)}");
            Console.WriteLine($"Park chevy:  {parkingLot.addCar(chevy)}");
            Console.WriteLine($"Park mazda:  {parkingLot.addCar(mazda)}\n");

            parkingLot.DisplayAll();

            Console.WriteLine($"\nCan subaru leave?  {parkingLot.removeCar(subaru)}");
            Console.WriteLine($"Can porche leave?  {parkingLot.removeCar(porche)}");
            Console.WriteLine($"Can ford leave?  {parkingLot.removeCar(ford)}\n");

            parkingLot.DisplayAll();
        }
    }
}
