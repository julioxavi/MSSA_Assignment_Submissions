﻿using System.Runtime.CompilerServices;
using System.Text;

namespace Assignment_10_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Part1();
            Part2();
            Part3();
            Part4();
            Part5();
        }

        //  **************************************** Part 1 ****************************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n________________________________________\n");

            Console.WriteLine("Let's write a program in c# to find the positive numbers from a list of numbers using 'where' conditions in LINQ!");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("\nGenerate random integer list and query positive numbers? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            var input = GenerateRandomIntList();
                            var output = FindPosNums(input);
                            Console.WriteLine($"\n------------------------------\nInput:  {{ {string.Join(", ", input)} }}");
                            Console.WriteLine($"Output: {{ {string.Join(", ", output)} }}\n------------------------------");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static List<int> GenerateRandomIntList()
        {
            Random r = new Random();
            List<int> input = new List<int>();
            int len = r.Next(5, 15);
            int count = 0;
            while (count < len)
            {
                input.Add(r.Next(-99, 100));
                count++;
            }
            return input;
        }
        static List<int> FindPosNums(List<int> input)
        {
            var output = input.Where(n => n >= 0).ToList();
            return output;
        }

        //  **************************************** Part 2 ****************************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n________________________________________\n");

            Console.WriteLine("Let's write a program that creates a list of employees and displays the ones who have salaries more than $50,000 and are less than 30 years old!\n");

            var employees = EmployeeList();
            Console.WriteLine($"Full list of employees:  \n------------------------------\n{DisplayEmployees(employees)}\n------------------------------\n");
            var filteredEmployees = FindEmployees(employees);
            Console.WriteLine($"List of employees under the age of 30 with salaries greater than $50,000:  \n------------------------------\n{DisplayEmployees(filteredEmployees)}\n------------------------------\n");

            Console.WriteLine("\nHave a nice day!\n");
        }
        static List<Employee> EmployeeList()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee(){ EmpName = "Suzy", EmpId = 4322, EmpAge = 23, EmpSalary = 89_500, EmpEmail = "suzy4322@email.com", EmpLocation = "TX" },
                new Employee(){ EmpName = "Allen", EmpId = 8734, EmpAge = 36, EmpSalary = 101_250, EmpEmail = "allen8734@email.com", EmpLocation = "NY" },
                new Employee(){ EmpName = "Frank", EmpId = 8425, EmpAge = 31, EmpSalary = 96_480, EmpEmail = "frank8425@email.com", EmpLocation = "AL" },
                new Employee(){ EmpName = "Gerald", EmpId = 8495, EmpAge = 28, EmpSalary = 40_000, EmpEmail = "gerald8495@email.com", EmpLocation = "MS" },
                new Employee(){ EmpName = "Henry", EmpId = 3645, EmpAge = 27, EmpSalary = 78_500, EmpEmail = "henry3645@email.com", EmpLocation = "IL" },
                new Employee(){ EmpName = "Amy", EmpId = 1258, EmpAge = 33, EmpSalary = 55_000, EmpEmail = "amy1258@email.com", EmpLocation = "TX" },
                new Employee(){ EmpName = "Bonny", EmpId = 0984, EmpAge = 42, EmpSalary = 120_000, EmpEmail = "bonny0984@email.com", EmpLocation = "CA" },
                new Employee(){ EmpName = "Sam", EmpId = 0025, EmpAge = 58, EmpSalary = 220_000, EmpEmail = "sam0025@email.com", EmpLocation = "CA" },
                new Employee(){ EmpName = "Ellie", EmpId = 9963, EmpAge = 45, EmpSalary = 180_000, EmpEmail = "ellie9963@email.com", EmpLocation = "NJ" },
                new Employee(){ EmpName = "Forest", EmpId = 7531, EmpAge = 26, EmpSalary = 78_000, EmpEmail = "forest7531@email.com", EmpLocation = "FL" },
            };
            return employees;
        }
        static List<Employee> FindEmployees(List<Employee> emps)
        {
            var findEmps = emps.Where(emp => emp.EmpAge < 30 && emp.EmpSalary > 50_000).Select(emp => new Employee { EmpName = emp.EmpName, EmpAge = emp.EmpAge, EmpSalary = emp.EmpSalary }).ToList();
            return findEmps;

            //  I had to write it like this because the way we did it in class with "select new {emp.Name, emp.Age, emp.Salary}" kept giving me an error because
            //  it was created as an annonymous class, even when I would wrap it like this: "(from...where...select new...).List()".  This way it is creating an employee class object
            //  and I'm able to pass it into other functions to use as a list of employees.
        }
        static string DisplayEmployees(List<Employee> emps)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var emp in emps)
            {
                sb.Append("\n");
                if (emp.EmpName != null)
                {
                    sb.Append($"Name:  {emp.EmpName}\t| ");
                }
                if (emp.EmpId != 0)
                {
                    sb.Append($"Id:  {emp.EmpId}\t| ");
                }
                if (emp.EmpAge != 0)
                {
                    sb.Append($"Age:  {emp.EmpAge}\t| ");
                }
                if (emp.EmpSalary != 0)
                {
                    sb.Append($"Salary:  {emp.EmpSalary:C}\t| ");
                }
                if (emp.EmpEmail != null)
                {
                    sb.Append($"Email:  {emp.EmpEmail}\t| ");
                }
                if (emp.EmpLocation != null)
                {
                    sb.Append($"Location:  {emp.EmpLocation}\t| ");
                }
                sb.Remove(sb.Length - 2, 2);
            }

            string result = sb.ToString();
            return result;
        }

        //  **************************************** Part 3 ****************************************
        static void Part3()
        {
            Console.WriteLine("Part 3:  \n________________________________________\n");

            Console.WriteLine("Let's write a program to find a string that starts and ends with a specific character!");

            string[] cities = { "ROME", "LONDON", "NAIROBI", "CALIFORNIA", "ZURICH", "NEW DEHLI", "AMSTERDAM", "ABU DHABI", "PARIS" };
            char startChar = 'a', endChar = 'z';

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("\nSearch for city? (y/n):  ");
                userInput = Console.ReadLine();
                Console.WriteLine();
                if(userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            Console.WriteLine("------------------------------");
                            Console.WriteLine("Please enter the starting and ending characters for the city being searched.");
                            do
                            {
                                Console.Write("Starts with:  ");
                                userInput = Console.ReadLine();
                                if (userInput != null)
                                {
                                    redFlag = char.TryParse(userInput.ToUpper(), out startChar) ? false : true;
                                }
                                else
                                {
                                    redFlag = true;
                                }
                                if (redFlag)
                                {
                                    Console.WriteLine("Invalid input.");
                                }
                            } while (redFlag);
                            do
                            {
                                Console.Write("Ends with:  ");
                                userInput = Console.ReadLine();
                                if (userInput != null)
                                {
                                    redFlag = char.TryParse(userInput.ToUpper(), out endChar) ? false : true;
                                }
                                else
                                {
                                    redFlag = true;
                                }
                                if (redFlag)
                                {
                                    Console.WriteLine("Invalid input.");
                                }
                            } while (redFlag);

                            var city = (from str in cities
                                       where str.StartsWith(startChar) && str.EndsWith(endChar)
                                       select str).ToArray();
                            if (city.Length == 0 || city == null)
                            {
                                Console.WriteLine($"There is no city that starts with '{startChar}' and ends with '{endChar}'.");
                            }
                            else if (city.Length == 1)
                            {
                                Console.WriteLine($"The city starting with '{startChar}' and ending in '{endChar}' is:  {string.Join(", ", city)}");
                            }
                            else
                            {
                                Console.WriteLine($"The cities starting with '{startChar}' and ending in '{endChar}' are:  {string.Join(", ", city)}");
                            }
                            Console.WriteLine("------------------------------");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine($"\n***** List of cities:  {{ {string.Join(", ", cities)} }} *****\n");

            Console.WriteLine("\nHave a nice day!\n");
        }

        //  **************************************** Part 4 ****************************************
        static void Part4()
        {
            Console.WriteLine("Part 4:  \n________________________________________\n");

            Console.WriteLine("Let's write a program to create a list of numbers and display the numbers that are greater than 80!");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("\nGenerate random integer list and query numbers greater than 80? (y/n):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            var input = GenerateRandomIntList2();
                            var output = input.Where(n => n > 80).ToList();
                            Console.WriteLine($"\n------------------------------\nInput:  {{ {string.Join(", ", input)} }}");
                            Console.WriteLine($"Output: {{ {string.Join(", ", output)} }}\n------------------------------");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input.");
                    redFlag = true;
                }
            } while (redFlag);
            

            Console.WriteLine("\nHave a nice day!\n");
        }
        static List<int> GenerateRandomIntList2()
        {
            Random r = new Random();
            List<int> input = new List<int>();
            int len = r.Next(5, 15);
            int count = 0;
            while (count < len)
            {
                input.Add(r.Next(0, 240));
                count++;
            }
            return input;
        }

        //  **************************************** Part 5 ****************************************
        static void Part5()
        {
            Console.WriteLine("Part 5:  \n________________________________________\n");

            Console.WriteLine("Let's take a given sorted character array and target and find the smallest character in the array that is lexocographically greater than the target character!\n");

            string? userInput = null;
            bool redFlag = true;

            do
            {
                Console.Write("Generate random sorted character array and target, then find the smallest character greater than the target? (yes/no):  ");
                userInput = Console.ReadLine();
                if (userInput != null)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            var input = GenerateRandomCharArray();
                            var target = GenerateRandomChar();
                            var output = FindChar(input, target);
                            Console.WriteLine($"------------------------------\nInput:  [ {string.Join(", ", input)} ]");
                            Console.WriteLine($"Target: '{target}'");
                            Console.WriteLine($"Output: '{output}'");
                            if (output == input[0] && output <= target)
                            {
                                Console.WriteLine($"There is no character in the array that is lexocographically greater than the target '{target}'.");
                            }
                            else
                            {
                                Console.WriteLine($"The smallest character in the array that is lexocographically greater than the target is: '{output}'");
                            }
                            Console.WriteLine("------------------------------\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "0":
                            redFlag = false;
                            break;
                        default:
                            Console.WriteLine("Invalid input.");
                            redFlag = true;
                            break;
                    }
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n");
        }
        static char[] GenerateRandomCharArray()
        {
            Random r = new Random();
            char[] input = new char[r.Next(5, 15)];
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = (char)r.Next('a', 'z' + 1);
            }
            input.Sort<char>();
            return input;
        }
        static char GenerateRandomChar()
        {
            Random r = new Random();
            char target = (char)r.Next('a', 'z' + 1);
            return target;
        }
        static char FindChar(char[] input, char target)
        {
            var output = input.Where(c => c > target).FirstOrDefault(input[0]);
            return output;
        }

    }
    class Employee
    {
        public string EmpName { get; set; }
        public int EmpId { get; set; }
        public int EmpAge { get; set; }
        public double EmpSalary { get; set; }
        public string EmpEmail { get; set; }
        public string EmpLocation { get; set; }
    }
}
