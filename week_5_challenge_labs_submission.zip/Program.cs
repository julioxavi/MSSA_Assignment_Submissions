﻿using System.ComponentModel.Design;

namespace Week_5_Challenge_Labs
{
    internal class Program
    {
        //  ********************************* -Main- ********************************
        static void Main(string[] args)
        {
            //Part1();
            Part2();
        }

        //  ********************************* Part 1 ********************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============");

            Console.WriteLine("Given a non-empty array of integers with elements that appear twice, let's find the sole element that only appears once!");

            string? userInput = null;
            bool redFlag = true;

            int[] nums;
            int target;

            do
            {
                Console.Write("\nFind target? (y/n):  ");
                userInput = Console.ReadLine();
                redFlag = userInput == null;
                if (!redFlag)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            nums = InitializeP1Array();
                            target = FindTarget(nums);
                            Console.WriteLine($"\n===============\nInput:  [{string.Join(',', nums)}]");
                            Console.WriteLine($"Output:  {target}\n===============\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "2":
                            redFlag = false;
                            break;
                        default:
                            redFlag = true;
                            Console.WriteLine("Invalid input.");
                            break;
                    }
                }
                else Console.WriteLine("Invalid input.");
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------");
        }
        static int[] InitializeP1Array()
        {
            bool redFlag = true;
            Random roll = new Random();
            int numCheck;

            List<int> elements1 = new List<int>();
            List<int> elements2 = new List<int>();

            int[] nums;
            int len = 0;

            do
            {
                numCheck = roll.Next(1, 20);
                if (numCheck % 2 != 0) len = numCheck;
            } while (numCheck % 2 == 0);
            nums = new int[len];
            for (int i = 0; i < len; i++)
            {
                do
                {
                    numCheck = roll.Next(21);
                    if (!elements1.Contains(numCheck) && elements1.Count < (len / 2) + 1)
                    {
                        nums[i] = numCheck;
                        elements1.Add(numCheck);
                        redFlag = false;
                    }
                    else if (elements1.Contains(numCheck) && !elements2.Contains(numCheck) && elements2.Count < len / 2)
                    {
                        nums[i] = numCheck;
                        elements2.Add(numCheck);
                        redFlag = false;
                    }
                    else redFlag = true;
                } while (redFlag);
            }
            return nums;
        }
        static int FindTarget(int[] nums)
        {
            Dictionary<int,int> numDups = new Dictionary<int,int>();    //  This list is to check the duplicates when searching for the target in the array.
            foreach (var num in nums)
            {
                if (!numDups.ContainsKey(num)) numDups[num] = num;
                else numDups.Remove(num);
            }
            int target = numDups.Values.First();
            return target;
        }

        //  ********************************* Part 2 ********************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============");

            Console.WriteLine("Given an array containing 'n' distinct numbers in sequence, let's return the missing number!");

            string? userInput = null;
            bool redFlag = true;

            int[] nums;
            int missing;

            do
            {
                Console.Write("\nFind missing number? (y/n):  ");
                userInput = Console.ReadLine();
                redFlag = userInput == null;
                if (!redFlag)
                {
                    switch (userInput.ToLower())
                    {
                        case "yes":
                        case "y":
                        case "1":
                            nums = InitializeP2Array();
                            missing = FindMissing(nums);
                            Console.WriteLine($"\n===============\nInput:  [{string.Join(',', nums)}]");
                            Console.WriteLine($"Output:  {missing}\n===============\n");
                            redFlag = true;
                            break;
                        case "no":
                        case "n":
                        case "2":
                            redFlag = false;
                            break;
                        default:
                            redFlag = true;
                            Console.WriteLine("Invalid input.");
                            break;
                    }
                }
                else Console.WriteLine("Invalid input.");
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------");
        }
        static int[] InitializeP2Array()
        {
            List<int> ints = new List<int>();
            Random roll = new Random();
            bool redFlag = true;

            int len = roll.Next(0, 21);
            int[] nums = new int[len];
            int numCheck = -1;

            for (int i = 0; i < len; i++)
            {
                do
                {
                    numCheck = roll.Next(len+1);
                    if (!ints.Contains(numCheck))
                    {
                        ints.Add(numCheck);
                        nums[i] = numCheck;
                        redFlag = false;
                    }
                    else
                    {
                        redFlag = true;
                    }
                } while (redFlag);
            }
            return nums;
        }
        static int FindMissing(int[] nums)
        {
            nums.Sort();

            if (nums.Length == 0) return 0;
            if (nums.Length == 1) return nums[0] == 0 ? 1 : 0;
            int low = 0;
            if (nums[low] != low) 
                return low;
            else if (nums[low + 1] != low + 1) 
                return low + 1;
            else 
                low++;
            int high = nums.Length;
            if (nums[high - 1] != high) 
                return high;
            else if (nums[high - 2] != high - 1) 
                return high - 1;
            else 
                high--;

            int missing = -1;
            bool redFlag = true;

            while (redFlag)
            {
                
                int mid = (low + high) / 2;
                if (nums[mid] == mid)
                {
                    if (nums[mid + 1] != mid + 1)
                    {
                        redFlag = false;
                        missing =  mid + 1;
                    }
                    else
                    {
                        low = mid;
                    }  
                }
                else
                {
                    if (nums[mid - 1] != mid)
                    {
                        redFlag = false;
                        missing = mid;
                    }
                    else
                    {
                        high = mid;
                    }
                }
            }
            return missing;
        }
    }
}
