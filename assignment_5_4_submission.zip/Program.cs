﻿using System.Globalization;

namespace Assignment_5_4
{
    internal class Program
    {
        //  ****************************** Part 1 ******************************
        static void Part1()
        {
            Console.WriteLine("Part 1:  \n===============\n");

            Console.WriteLine("Let's write a program to display the individual digits of a given number using recursion!\n");

            string? userInput = null;
            bool redFlag = false;
            Random random = new Random();

            int n;
            List<int> digits = new List<int>();

            do
            {
                Console.Write("Display digits? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y" || userInput.ToLower().Trim() == "1");
                if (redFlag)
                {
                    n = random.Next(int.MinValue, int.MaxValue);
                    Console.WriteLine("\n===============");
                    Console.WriteLine($"Input:  {n}");
                    DisplayDigits(n, digits);
                    Console.WriteLine("\n===============\n");
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void DisplayDigits(int n, List<int> digits)
        {
            if (n < 0) n *= -1;
            if (n < 10)
            {
                Console.Write($"Digits:  ");
                digits.Add(n);
                digits.Reverse();
                foreach (int d in digits) Console.Write($"{d} ");
                digits.Clear();
            }
            else
            {
                digits.Add(n % 10);
                DisplayDigits(n / 10, digits);
            }
        }

        //  ****************************** Part 2 ******************************
        static void Part2()
        {
            Console.WriteLine("Part 2:  \n===============\n");

            Console.WriteLine("Let's find the sum of the diagonals of a matrix!");

            string? userInput = null;
            bool redFlag = false;
            Random roll = new Random();

            int squareSize;
            int[,] squareMatrix;
            int rightDiagonalSum;
            int leftDiagonalSum;

            do
            {
                Console.Write("\nDisplay matrix and find sum of diagonals? (yes/no):  ");
                userInput = Console.ReadLine();
                redFlag = userInput != null && (userInput.ToLower().Trim() == "yes" || userInput.ToLower().Trim() == "y" || userInput.ToLower().Trim() == "1");
                if (redFlag)
                {
                    squareSize = roll.Next(2, 10);
                    squareMatrix = new int[squareSize, squareSize];
                    for (int i = 0; i <  squareSize; i++)
                    {
                        for (int j = 0; j < squareSize; j++)
                        {
                            squareMatrix[i, j] = roll.Next(10, 100);
                        }
                    }
                    AddDiagonals(squareMatrix, squareSize, out rightDiagonalSum, out leftDiagonalSum);
                    Console.WriteLine($"\nMatrix size:  {squareSize}");
                    Console.WriteLine($"\nThe matrix is:  \n===============");
                    DisplayMatrix(squareMatrix, squareSize);
                    Console.WriteLine($"===============\n\n");
                    Console.Write($"Addition of ");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("right");
                    Console.ResetColor();
                    Console.WriteLine($" diagonal elements:  {rightDiagonalSum}");
                    Console.Write($"Addition of ");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("left");
                    Console.ResetColor();
                    Console.WriteLine($" diagonal elements:  {leftDiagonalSum}");
                }
            } while (redFlag);

            Console.WriteLine("\nHave a nice day!\n------------------------------\n");
        }
        static void DisplayMatrix(int[,] matrix, int size)
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if ((i == size - j - 1 && j == size - i - 1) && i == j)
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.Write($"{matrix[i,j]} ");
                        Console.ResetColor();
                    }
                    else if (i == j)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write($"{matrix[i, j]} ");
                        Console.ResetColor();
                    }
                    else if (i == size - j - 1 && j == size - i - 1)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write($"{matrix[i, j]} ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write($"{matrix[i, j]} ");
                    }
                }
                Console.WriteLine();
            }
        }
        static void AddDiagonals(int[,] matrix, int size, out int rsum, out int lsum)
        {
            rsum = 0;
            lsum = 0;
            for (int i = 0; i < size; i++)
            {
                rsum += matrix[i, i];
                lsum += matrix[size - 1 - i, i];
            }
        }
        static void Main(string[] args)
        {
            Part1();
            Part2();
        }
    }
}
